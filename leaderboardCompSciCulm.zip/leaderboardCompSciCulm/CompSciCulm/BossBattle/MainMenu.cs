﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BossBattle
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (!File.Exists("LB.txt"))
            {
                StreamWriter sw = new StreamWriter("LB.txt");
                sw.WriteLine(".Score\t.Name");
                sw.Close();
            }
            var FormBossBattle = new FrmBossBattle();
            FormBossBattle.Show();
            this.Hide();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
