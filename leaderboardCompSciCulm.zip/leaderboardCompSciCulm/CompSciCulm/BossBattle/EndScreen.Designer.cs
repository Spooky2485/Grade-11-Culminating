﻿namespace BossBattle
{
    partial class EndScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblThanks = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnLB = new System.Windows.Forms.Button();
            this.txtboxLB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblThanks
            // 
            this.lblThanks.AutoSize = true;
            this.lblThanks.BackColor = System.Drawing.Color.Transparent;
            this.lblThanks.ForeColor = System.Drawing.Color.Black;
            this.lblThanks.Location = new System.Drawing.Point(285, 40);
            this.lblThanks.Name = "lblThanks";
            this.lblThanks.Size = new System.Drawing.Size(147, 13);
            this.lblThanks.TabIndex = 0;
            this.lblThanks.Text = "Thanks For Playing our Game";
            // 
            // btnQuit
            // 
            this.btnQuit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnQuit.Location = new System.Drawing.Point(278, 274);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(164, 42);
            this.btnQuit.TabIndex = 1;
            this.btnQuit.Text = "Quit To Desktop";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnMenu.Location = new System.Drawing.Point(278, 202);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(164, 40);
            this.btnMenu.TabIndex = 2;
            this.btnMenu.Text = "Quit To Main Menu";
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnLB
            // 
            this.btnLB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLB.Location = new System.Drawing.Point(278, 125);
            this.btnLB.Name = "btnLB";
            this.btnLB.Size = new System.Drawing.Size(164, 39);
            this.btnLB.TabIndex = 3;
            this.btnLB.Text = "Leaderboard";
            this.btnLB.UseVisualStyleBackColor = true;
            this.btnLB.Click += new System.EventHandler(this.btnLB_Click);
            // 
            // txtboxLB
            // 
            this.txtboxLB.Location = new System.Drawing.Point(517, 89);
            this.txtboxLB.Multiline = true;
            this.txtboxLB.Name = "txtboxLB";
            this.txtboxLB.ReadOnly = true;
            this.txtboxLB.Size = new System.Drawing.Size(100, 290);
            this.txtboxLB.TabIndex = 4;
            this.txtboxLB.Visible = false;
            // 
            // EndScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 426);
            this.Controls.Add(this.txtboxLB);
            this.Controls.Add(this.btnLB);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.lblThanks);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.Name = "EndScreen";
            this.Text = "EndScreen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblThanks;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Button btnLB;
        private System.Windows.Forms.TextBox txtboxLB;
    }
}