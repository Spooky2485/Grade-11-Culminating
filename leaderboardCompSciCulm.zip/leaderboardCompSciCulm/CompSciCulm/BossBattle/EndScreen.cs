﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BossBattle
{
    public partial class EndScreen : Form
    {
        public EndScreen()
        {
            InitializeComponent();
        }
        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();//closes applicaiton
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            var FormBossBattle = new MainMenu();
            FormBossBattle.Show();
            this.Hide();
        }

        private void btnLB_Click(object sender, EventArgs e)
        {

            string sortfile = @"LB.txt";//makes the file a string
            string[] sort = File.ReadAllLines(sortfile);//reads the file and creates an array
            Array.Sort(sort);//sort function to sort it
            File.WriteAllLines(sortfile, sort);//sorts by the two variables declared above

            txtboxLB.Visible = true;//makes the leaderboard visible which is a read only multiline text file
            StreamReader sr = new StreamReader("LB.txt");//reads the file
            txtboxLB.Text = sr.ReadToEnd();//reads the file into the text box
            sr.Close();//closes the streamreader
        }
    }
}
