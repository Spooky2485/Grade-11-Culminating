﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;


namespace BossBattle
{
    public partial class FrmBossBattle : Form
    { 

        double monsterHealth = 1000;
        double monsterHealthOg = 1000;
        double playerHealth = 1000;
        double PlayerHealthOg = 1000;
        int Turn = 1;
        int Num1 = 2;
        int MonsterAcuracy = 55;
        int TurnCopy = -3;
        int score = 0;
       
        //set up components
        public FrmBossBattle()
        {   
            
            InitializeComponent();
            btnLightAttack.Visible = false;
            btnHeavyAttack.Visible = false;
            textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;
            textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health

            picBoxBackground.Controls.Add(IdleMove); // IdleMove added to background
            IdleMove.Location = new Point(83, 100); // Location is validated
            IdleMove.BackColor = Color.Transparent; // Transparency is validated
            IdleMove.Visible = true;
            LightAttackAnimation.Visible = false;
        }

       
        public async void AttackAnimLightAttackAsync()
        {
            picBoxBackground.Controls.Remove(IdleMove); // removes idle animation
            picBoxBackground.Controls.Add(LightAttackAnimation); // adds light attack animation
            LightAttackAnimation.Location = new Point(83, 100); // declares location
            LightAttackAnimation.BackColor = Color.Transparent; // declares color/transparency
            LightAttackAnimation.Visible = true; // declares visibility as true of light attack anim
            await Task.Delay(1750); // 1.75 seconds delay to hold attack
            LightAttackAnimation.Visible = false; // declares visibility as false of light attack anim
            picBoxBackground.Controls.Remove(LightAttackAnimation); // removes light attack anim since it has played out
            IdleAnim2(); //jumps back to idle animation function
        }
        public async void IdleAnim2()
        {
            picBoxBackground.Controls.Add(IdleMove); // added idle aniation
            IdleMove.Location = new Point(83, 100); // declares location
            IdleMove.BackColor = Color.Transparent; // declares transparency/color
            IdleMove.Visible = true; // declares visibility as true of idle anim

        }
        public void MonsterAccuracyCheck()
        {
            if(Turn < (TurnCopy + 3))
            {
                MonsterAcuracy = 20;
            }
            else
            {
                MonsterAcuracy = 55;
            }
        }


        public void DeathCheck()
        {
            if (monsterHealth < 0)
            {
                MessageBox.Show("You Win");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();

            }
            if (playerHealth < 0)
            {
                MessageBox.Show("You Lose");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();
            }
        }

        

        public void LeaderBoard()
        {
            int btnheavy = Convert.ToInt16(btnHeavyAttack);//list of variables
            int btnlight = Convert.ToInt16(btnLightAttack);
            int btnstun = Convert.ToInt16(btnStun);
            int btnblock = Convert.ToInt16(btnProtect);
            int btnheal = Convert.ToInt16(btnHeal);
            int lightattack = 100;
            int heavyattack = 150;
            int heal = 50;
            int stun = 500;
            int block = 200;
            int monsterhealthgone = 1000;
            int turns = Convert.ToInt16(textBoxTurn.Text);
            

            while (true)
            {
                if ( btnlight == turns)
                {
                    textBoxTurn.Text += score + lightattack;
                }
                else if (btnheavy == turns)
                {
                    textBoxTurn.Text += score + heavyattack;
                }
                else if (btnheal == turns)
                {
                    textBoxTurn.Text += score + heal;
                }
                else if (btnstun == turns)
                {
                    textBoxTurn.Text += score + stun;
                }
                else if (btnblock == turns)
                {
                    textBoxTurn.Text += score + block;
                }
                if (monsterHealth <= 0)
                {
                    textBoxTurn.Text += score + monsterhealthgone;
                }
                if (monsterHealth <= 0)
                {
                    StreamWriter sw = new StreamWriter("LB.txt");
                    sw.WriteLine("\n" + score);
                    sw.Close();
                }
            }
            
            /*
            while (Convert.ToInt16(textBoxTurn.Text) >= turns)
            {
                if (btnlight == Convert.ToInt16(textBoxTurn.Text))
                {
                    btnlight = score + lightattack;
                }
                else if (btnheavy == Convert.ToInt16(textBoxTurn.Text))
                {
                    btnheavy = score + heavyattack;
                }
                else if (heal == Convert.ToInt16(textBoxTurn.Text))
                {
                    btnheal = score + heal;
                }
                else if (stun == Convert.ToInt16(textBoxTurn.Text))
                {
                    btnstun = score + stun;
                }
                else if (block == Convert.ToInt16(textBoxTurn.Text))
                {
                    btnblock = score + block;
                }
                else if (monsterhealthgone == Convert.ToInt16(textBoxTurn.Text))
                {
                    textBoxTurn.Text += score + monsterhealthgone;
                }
            }
            
                
                successful LightAttack = +100;
                successful HeavyAttack = +150;
                successful Heal = +50;
                successful Stun = +500;
                successful Protect = +200;
                successful monsterHealth/0 = +1000;
                */
            
            
        }

        //MonsterAi
        public async Task AiAttackAsync()
        {
            await Task.Delay(1000);
            Random MovesRng = new Random();
            int MovesChoice = MovesRng.Next(0, 4);
            //Thread.Sleep(timeout2);
            //Thread.Sleep(timeout2);
            //FireBall
            if(MovesChoice == 0)
            {
                textBoxDialog.Text = "";
                Random FireBallRamNumChance = new Random();
                int FireBallChance = FireBallRamNumChance.Next(0, 101);
                
                if (FireBallChance <= MonsterAcuracy) //if the generated fireballchance is greater than the monster's accuracy, then the attack will follow thrugh.
                {
                    Random FireBallRamNum = new Random();
                    double FireBall = FireBallRamNum.Next(70, 111);//chance for dmg
                    if (FireBallChance <= 9)//chance of crit 15%
                    {
                        playerHealth = playerHealth - (FireBall * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text =  playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                        playerHealth = playerHealth - FireBall;
                        textBoxPlayerHealth.Text =  + playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text =   playerHealth + "/" + PlayerHealthOg;//health
                }
            }
            //Rock Throw
            if (MovesChoice == 1)
            {
                textBoxDialogMonster.Text = "";
                Random RockThrowRamNumChance = new Random();
                int RockThrowChance = RockThrowRamNumChance.Next(0, 101);
                if (RockThrowChance <= MonsterAcuracy)//chance of attacking
                {
                    Random RockThrowRamNum = new Random();
                    double RockThrow = RockThrowRamNum.Next(70, 111);//chance for dmg
                    if (RockThrowChance <= 9)//chance of crit 15%
                    {
                        playerHealth = playerHealth - (RockThrow * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                        playerHealth = playerHealth - RockThrow;
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                }
            }
            //Ice Spear
            if (MovesChoice == 2)
            {
                textBoxDialogMonster.Text = "";
                Random IceSpearRamNumChance = new Random();
                int IceSpearChance = IceSpearRamNumChance.Next(0, 101);
                if (IceSpearChance <= MonsterAcuracy)//chance of attacking
                {
                    Random IceSpearRamNum = new Random();
                    double IceSpear = IceSpearRamNum.Next(70, 111);//chance for dmg
                    if (IceSpearChance <= 9)//chance of crit 15%
                    {
                        playerHealth = playerHealth - (IceSpear * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                        playerHealth = playerHealth - IceSpear;
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                }
            }
            //Vine Slash
            if (MovesChoice == 3)
            {
                textBoxDialogMonster.Text = "";
                Random VineSlashRamNumChance = new Random();
                int VineSlashChance = VineSlashRamNumChance.Next(0, 101);
                if (VineSlashChance <= MonsterAcuracy)//chance of attacking
                {
                    Random VineSlashRamNum = new Random();
                    double VineSlash = VineSlashRamNum.Next(70, 111);//chance for dmg
                    if (VineSlashChance <= 9)//chance of crit 15%
                    {
                        playerHealth = playerHealth - (VineSlash * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                        playerHealth = playerHealth - VineSlash;
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                }
            }


        }

        
        //fight select
        private void btnFight_Click(object sender, EventArgs e)
        {
            Num1 = Num1 % 2;//even numbers have no decimals fight starts at 2 so the buttons start of not visible but when clicked it increases fight by 1
            if (Num1 > 0)
            {
                btnLightAttack.Visible = false;
                btnHeavyAttack.Visible = false;
            }
            else
            {
                btnLightAttack.Visible = true;
                btnHeavyAttack.Visible = true;
            }
            Num1 += 1;
            
        }


        //Heavy attack
        private async void btnHeavyAttack_ClickAsync(object sender, EventArgs e)
        {
            //use while loop to make sure the user isnt able to spam
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HRamNumChance = new Random();
            int HeavyAttackChance = HRamNumChance.Next(0, 101);

            if (HeavyAttackChance <= 60)//chance of attacking
            {
                Random HRamNum = new Random();
                double HeavyAttack = HRamNum.Next(40, 81);//chance for dmg
                if(HeavyAttackChance <= 9)//chance of crit 15%
                {
                    monsterHealth = monsterHealth - (HeavyAttack * 1.25);//crit multiplier and attack
                    textBoxDialog.Text = "Critical Hit!";//dialog
                    textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
                }
                else
                {
                    monsterHealth = monsterHealth - HeavyAttack;
                    textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
                }
                
            }
            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;
            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }

        //Light attack
        private async void btnLightAttack_ClickAsync(object sender, EventArgs e)
        {
            AttackAnimLightAttackAsync(); // initiates animation
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            //TimeSpan timeout = new TimeSpan(0, 0, 1);
            textBoxDialog.Text = "";
            Random LRamNumChance = new Random();
            int LightAttackChance = LRamNumChance.Next(1, 2); //was 0,101
            //Thread.Sleep(timeout);

            if (LightAttackChance <= 100)//chance of attacking was 95
            {
                Random LRamNum = new Random();
                double LightAttack = LRamNum.Next(30000, 510000);//chance for dmg was 30,51
                if (LightAttackChance <= 14.25)//chance of crit 15%
                {
                    monsterHealth = monsterHealth - (LightAttack * 1.25);//crit multiplier and attack
                    textBoxDialog.Text = "Critical Hit!";//dialog
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                }
                else
                {
                    monsterHealth = monsterHealth - LightAttack;//attack
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                }
            }

            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;
            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
        }
        //Heal
        private async void btnHeal_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HealRamNumChance = new Random();
            int HealChance = HealRamNumChance.Next(0, 101);
            
            if ( HealChance <= 75)
            {
                playerHealth = playerHealth * 1.20;
                if (playerHealth > PlayerHealthOg)
                {
                    playerHealth = PlayerHealthOg;
                }
                textBoxDialog.Text = "Healed";
                
            }
            else
            {
                monsterHealth = monsterHealth * 1.05;
                if (monsterHealth > monsterHealthOg)
                {
                    monsterHealth = monsterHealthOg;
                }
                textBoxDialogMonster.Text = "Healed";
                
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;
            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
        }


        //Stun
        private async void btnStun_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random StunRamNumChance = new Random();
            int StunChance = StunRamNumChance.Next(0, 101);
            TurnCopy = Turn;
            if (StunChance >= 75)
            {
                TurnCopy = Turn;
            }
            else
            {
                playerHealth = playerHealth - 100;
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;
            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
            
        }
        //Protect
        private async void btnProtect_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);

            // code here

            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }

        
    }
}
