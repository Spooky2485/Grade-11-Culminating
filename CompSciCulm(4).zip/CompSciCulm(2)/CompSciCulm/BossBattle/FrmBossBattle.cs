﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;


namespace BossBattle
{
    public partial class FrmBossBattle : Form
    {
        
        double monsterHealth = 1000;
        double monsterHealthOg = 1000;
        double playerHealth = 1000;
        double PlayerHealthOg = 1000;
        int Turn = 1;
        int Num1 = 2;
        int MonsterAcuracy = 55;
        int TurnCopy = -3;
       
        //set up components
        public FrmBossBattle()
        {   
            InitializeComponent();
            btnLightAttack.Visible = false;
            btnHeavyAttack.Visible = false;
            textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;
            textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
        }
        public void MonsterAccuracyCheck()
        {
            if(Turn < (TurnCopy + 3))
            {
                MonsterAcuracy = 20;
            }
            else
            {
                MonsterAcuracy = 55;
            }
        }
        

        public void DeathCheck()
        {
            if (monsterHealth < 0)
            {
                MessageBox.Show("You Win");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();

            }
            if (playerHealth < 0)
            {
                MessageBox.Show("You Lose");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();
            }
        }

        

        //MonsterAi
        public async Task AiAttackAsync()
        {
            await Task.Delay(1000);
            Random MovesRng = new Random();
            int MovesChoice = MovesRng.Next(0, 4);
            //Thread.Sleep(timeout2);
            //Thread.Sleep(timeout2);
            //FireBall
            if(MovesChoice == 0)
            {
                textBoxDialog.Text = "";
                Random FireBallRamNumChance = new Random();
                int FireBallChance = FireBallRamNumChance.Next(0, 101);
                
                if (FireBallChance <= MonsterAcuracy) //if the generated fireballchance is greater than the monster's accuracy, then the attack will follow thrugh.
                {
                    Random FireBallRamNum = new Random();
                    double FireBall = FireBallRamNum.Next(70, 111);//chance for dmg
                    if (FireBallChance <= 9)//chance of crit 15%
                    {
                        playerHealth = playerHealth - (FireBall * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text =  playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                        playerHealth = playerHealth - FireBall;
                        textBoxPlayerHealth.Text =  + playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text =   playerHealth + "/" + PlayerHealthOg;//health
                }
            }
            //Rock Throw
            if (MovesChoice == 1)
            {
                textBoxDialogMonster.Text = "";
                Random RockThrowRamNumChance = new Random();
                int RockThrowChance = RockThrowRamNumChance.Next(0, 101);
                if (RockThrowChance <= MonsterAcuracy)//chance of attacking
                {
                    Random RockThrowRamNum = new Random();
                    double RockThrow = RockThrowRamNum.Next(70, 111);//chance for dmg
                    if (RockThrowChance <= 9)//chance of crit 15%
                    {
                        playerHealth = playerHealth - (RockThrow * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                        playerHealth = playerHealth - RockThrow;
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                }
            }
            //Ice Spear
            if (MovesChoice == 2)
            {
                textBoxDialogMonster.Text = "";
                Random IceSpearRamNumChance = new Random();
                int IceSpearChance = IceSpearRamNumChance.Next(0, 101);
                if (IceSpearChance <= MonsterAcuracy)//chance of attacking
                {
                    Random IceSpearRamNum = new Random();
                    double IceSpear = IceSpearRamNum.Next(70, 111);//chance for dmg
                    if (IceSpearChance <= 9)//chance of crit 15%
                    {
                        playerHealth = playerHealth - (IceSpear * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                        playerHealth = playerHealth - IceSpear;
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                }
            }
            //Vine Slash
            if (MovesChoice == 3)
            {
                textBoxDialogMonster.Text = "";
                Random VineSlashRamNumChance = new Random();
                int VineSlashChance = VineSlashRamNumChance.Next(0, 101);
                if (VineSlashChance <= MonsterAcuracy)//chance of attacking
                {
                    Random VineSlashRamNum = new Random();
                    double VineSlash = VineSlashRamNum.Next(70, 111);//chance for dmg
                    if (VineSlashChance <= 9)//chance of crit 15%
                    {
                        playerHealth = playerHealth - (VineSlash * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                        playerHealth = playerHealth - VineSlash;
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                }
            }


        }

        
        //fight select
        private void btnFight_Click(object sender, EventArgs e)
        {
            Num1 = Num1 % 2;//even numbers have no decimals fight starts at 2 so the buttons start of not visible but when clicked it increases fight by 1
            if (Num1 > 0)
            {
                btnLightAttack.Visible = false;
                btnHeavyAttack.Visible = false;
            }
            else
            {
                btnLightAttack.Visible = true;
                btnHeavyAttack.Visible = true;
            }
            Num1 += 1;
            
        }


        //Heavy attack
        private async void btnHeavyAttack_ClickAsync(object sender, EventArgs e)
        {
            //use while loop to make sure the user isnt able to spam
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HRamNumChance = new Random();
            int HeavyAttackChance = HRamNumChance.Next(0, 101);

            if (HeavyAttackChance <= 60)//chance of attacking
            {
                Random HRamNum = new Random();
                double HeavyAttack = HRamNum.Next(40, 81);//chance for dmg
                if(HeavyAttackChance <= 9)//chance of crit 15%
                {
                    monsterHealth = monsterHealth - (HeavyAttack * 1.25);//crit multiplier and attack
                    textBoxDialog.Text = "Critical Hit!";//dialog
                    textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
                }
                else
                {
                    monsterHealth = monsterHealth - HeavyAttack;
                    textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
                }
                
            }
            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;
            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }

        //Light attack
        private async void btnLightAttack_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            //TimeSpan timeout = new TimeSpan(0, 0, 1);
            textBoxDialog.Text = "";
            Random LRamNumChance = new Random();
            int LightAttackChance = LRamNumChance.Next(0, 101);
            //Thread.Sleep(timeout);

            if (LightAttackChance <= 95)//chance of attacking
            {
                Random LRamNum = new Random();
                double LightAttack = LRamNum.Next(30, 51);//chance for dmg
                if (LightAttackChance <= 14.25)//chance of crit 15%
                {
                    monsterHealth = monsterHealth - (LightAttack * 1.25);//crit multiplier and attack
                    textBoxDialog.Text = "Critical Hit!";//dialog
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                }
                else
                {
                    monsterHealth = monsterHealth - LightAttack;//attack
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                }
            }

            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;
            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
        }
        //Heal
        private async void btnHeal_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HealRamNumChance = new Random();
            int HealChance = HealRamNumChance.Next(0, 101);
            
            if ( HealChance <= 75)
            {
                playerHealth = playerHealth * 1.20;
                if (playerHealth > PlayerHealthOg)
                {
                    playerHealth = PlayerHealthOg;
                }
                textBoxDialog.Text = "Healed";
                
            }
            else
            {
                monsterHealth = monsterHealth * 1.05;
                if (monsterHealth > monsterHealthOg)
                {
                    monsterHealth = monsterHealthOg;
                }
                textBoxDialogMonster.Text = "Healed";
                
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;
            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
        }


        //Stun
        private async void btnStun_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random StunRamNumChance = new Random();
            int StunChance = StunRamNumChance.Next(0, 101);
            TurnCopy = Turn;
            if (StunChance >= 75)
            {
                TurnCopy = Turn;
            }
            else
            {
                playerHealth = playerHealth - 100;
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;
            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
        }
        //Protect
        private async void btnProtect_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);

            // code here

            btnFight.Visible = true;
            btnHeavyAttack.Visible = true;
            btnLightAttack.Visible = true;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }

        
    }
}
