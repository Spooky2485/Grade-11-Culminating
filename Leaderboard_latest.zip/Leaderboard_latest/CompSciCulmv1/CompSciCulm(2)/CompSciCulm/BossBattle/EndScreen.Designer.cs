﻿namespace BossBattle
{
    partial class EndScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.End = new System.Windows.Forms.Label();
            this.btnLB = new System.Windows.Forms.Button();
            this.btnMainmnu = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.txtboxLB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // End
            // 
            this.End.AutoSize = true;
            this.End.BackColor = System.Drawing.SystemColors.Control;
            this.End.Location = new System.Drawing.Point(294, 35);
            this.End.Name = "End";
            this.End.Size = new System.Drawing.Size(152, 13);
            this.End.TabIndex = 0;
            this.End.Text = "Thanks For Playing Our Game!";
            // 
            // btnLB
            // 
            this.btnLB.Location = new System.Drawing.Point(297, 135);
            this.btnLB.Name = "btnLB";
            this.btnLB.Size = new System.Drawing.Size(160, 40);
            this.btnLB.TabIndex = 1;
            this.btnLB.Text = "Leaderboard";
            this.btnLB.UseVisualStyleBackColor = true;
            this.btnLB.Click += new System.EventHandler(this.btnLB_Click);
            // 
            // btnMainmnu
            // 
            this.btnMainmnu.Location = new System.Drawing.Point(297, 221);
            this.btnMainmnu.Name = "btnMainmnu";
            this.btnMainmnu.Size = new System.Drawing.Size(160, 40);
            this.btnMainmnu.TabIndex = 2;
            this.btnMainmnu.Text = "Quit to Main Menu";
            this.btnMainmnu.UseVisualStyleBackColor = true;
            this.btnMainmnu.Click += new System.EventHandler(this.btnMainmnu_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(297, 296);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(160, 40);
            this.btnQuit.TabIndex = 3;
            this.btnQuit.Text = "Quit To Desktop";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // txtboxLB
            // 
            this.txtboxLB.Location = new System.Drawing.Point(544, 135);
            this.txtboxLB.Multiline = true;
            this.txtboxLB.Name = "txtboxLB";
            this.txtboxLB.ReadOnly = true;
            this.txtboxLB.Size = new System.Drawing.Size(123, 201);
            this.txtboxLB.TabIndex = 4;
            // 
            // EndScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtboxLB);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnMainmnu);
            this.Controls.Add(this.btnLB);
            this.Controls.Add(this.End);
            this.Name = "EndScreen";
            this.Text = "EndScreen";
           
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label End;
        private System.Windows.Forms.Button btnLB;
        private System.Windows.Forms.Button btnMainmnu;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.TextBox txtboxLB;
    }
}