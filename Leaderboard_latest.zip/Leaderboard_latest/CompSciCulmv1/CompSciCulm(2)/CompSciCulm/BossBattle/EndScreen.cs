﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BossBattle
{

    public partial class EndScreen : Form
    {
        public int _turn;
        public int Turn
        {
            get { return _turn; }
            set { Turn = value; }
        }

        public EndScreen()
        {
                InitializeComponent();
        }

        

        private void btnQuit_Click(object sender, EventArgs e)
        {
                Application.Exit();
        }

            private void btnMainmnu_Click(object sender, EventArgs e)
            {
                var FormMainMenu = new MainMenu();
                FormMainMenu.Show();
                this.Hide();
            }

        private void btnLB_Click(object sender, EventArgs e)
        {
            int score = Turn;

            if (!File.Exists(@"LB.txt"))
            {
                StreamWriter sw1 = new StreamWriter(@"LB.txt");
                sw1.WriteLine(".Score\tName");
                sw1.Close();
            }
            if (File.Exists(@"LB.txt"))
            {
                StreamWriter sw1 = new StreamWriter(@"LB.txt");
                sw1.WriteLine(".Score\tName");
                sw1.Close();
            }

            StreamWriter sw = new StreamWriter(@"LB.txt");
            sw.WriteLine(".Score\tName");
            sw.WriteLine(score);
            sw.Close();
                
            string[] sort = File.ReadAllLines(@"LB.txt");//reads the file and creates an array
            Array.Sort(sort);//sort function to sort it
            File.WriteAllLines("LB.txt", sort);//sorts by the two variables declared above

            txtboxLB.Visible = true;//makes the leaderboard visible which is a read only multiline text file
            StreamReader sr = new StreamReader(@"LB.txt");//reads the file
            txtboxLB.Text = sr.ReadToEnd();//reads the file into the text box
            sr.Close();//closes the streamreader
        }

        
    }
}
