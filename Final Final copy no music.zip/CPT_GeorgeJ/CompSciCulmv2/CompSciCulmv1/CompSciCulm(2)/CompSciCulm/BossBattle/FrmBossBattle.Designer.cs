﻿namespace BossBattle
{
    partial class FrmBossBattle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBossBattle));
            this.btnLightAttack = new System.Windows.Forms.Button();
            this.btnHeavyAttack = new System.Windows.Forms.Button();
            this.textBoxMonsterHealth = new System.Windows.Forms.TextBox();
            this.btnFight = new System.Windows.Forms.Button();
            this.btnHeal = new System.Windows.Forms.Button();
            this.btnStun = new System.Windows.Forms.Button();
            this.btnProtect = new System.Windows.Forms.Button();
            this.textBoxDialog = new System.Windows.Forms.TextBox();
            this.picBoxBackground = new System.Windows.Forms.PictureBox();
            this.textBoxPlayerHealth = new System.Windows.Forms.TextBox();
            this.textBoxDialogMonster = new System.Windows.Forms.TextBox();
            this.textBoxTurn = new System.Windows.Forms.TextBox();
            this.LightAttackAnimation = new System.Windows.Forms.PictureBox();
            this.IdleMove = new System.Windows.Forms.PictureBox();
            this.HeavyAttackAnimation = new System.Windows.Forms.PictureBox();
            this.DeathAnim = new System.Windows.Forms.PictureBox();
            this.Health = new System.Windows.Forms.PictureBox();
            this.PlayerHitAnimation = new System.Windows.Forms.PictureBox();
            this.bossattack = new System.Windows.Forms.PictureBox();
            this.bossidle = new System.Windows.Forms.PictureBox();
            this.Bosshealth = new System.Windows.Forms.ProgressBar();
            this.playerhealthbar = new System.Windows.Forms.ProgressBar();
            this.ItemPanel = new System.Windows.Forms.Panel();
            this.btnDrop = new System.Windows.Forms.Button();
            this.btnInfo = new System.Windows.Forms.Button();
            this.btnUse = new System.Windows.Forms.Button();
            this.btnItem10 = new System.Windows.Forms.Button();
            this.btnItem9 = new System.Windows.Forms.Button();
            this.btnItem8 = new System.Windows.Forms.Button();
            this.btnItem7 = new System.Windows.Forms.Button();
            this.btnItem6 = new System.Windows.Forms.Button();
            this.btnItem5 = new System.Windows.Forms.Button();
            this.btnItem4 = new System.Windows.Forms.Button();
            this.btnItem3 = new System.Windows.Forms.Button();
            this.btnItem2 = new System.Windows.Forms.Button();
            this.btnItem1 = new System.Windows.Forms.Button();
            this.btnItemMenuHandle = new System.Windows.Forms.Button();
            this.bossDamaged = new System.Windows.Forms.PictureBox();
            this.bossDeath = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBackground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LightAttackAnimation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IdleMove)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeavyAttackAnimation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DeathAnim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Health)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHitAnimation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossattack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossidle)).BeginInit();
            this.ItemPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bossDamaged)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossDeath)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLightAttack
            // 
            this.btnLightAttack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLightAttack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLightAttack.Location = new System.Drawing.Point(29, 350);
            this.btnLightAttack.Name = "btnLightAttack";
            this.btnLightAttack.Size = new System.Drawing.Size(100, 40);
            this.btnLightAttack.TabIndex = 0;
            this.btnLightAttack.Text = "Light Attack\r\n";
            this.btnLightAttack.UseVisualStyleBackColor = true;
            this.btnLightAttack.Click += new System.EventHandler(this.btnLightAttack_ClickAsync);
            // 
            // btnHeavyAttack
            // 
            this.btnHeavyAttack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHeavyAttack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHeavyAttack.Location = new System.Drawing.Point(135, 350);
            this.btnHeavyAttack.Name = "btnHeavyAttack";
            this.btnHeavyAttack.Size = new System.Drawing.Size(100, 40);
            this.btnHeavyAttack.TabIndex = 1;
            this.btnHeavyAttack.Text = "Heavy Attack\r\n";
            this.btnHeavyAttack.UseVisualStyleBackColor = true;
            this.btnHeavyAttack.Click += new System.EventHandler(this.btnHeavyAttack_ClickAsync);
            // 
            // textBoxMonsterHealth
            // 
            this.textBoxMonsterHealth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxMonsterHealth.Enabled = false;
            this.textBoxMonsterHealth.Location = new System.Drawing.Point(196, 50);
            this.textBoxMonsterHealth.Name = "textBoxMonsterHealth";
            this.textBoxMonsterHealth.Size = new System.Drawing.Size(192, 13);
            this.textBoxMonsterHealth.TabIndex = 4;
            this.textBoxMonsterHealth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnFight
            // 
            this.btnFight.BackColor = System.Drawing.Color.Transparent;
            this.btnFight.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFight.Location = new System.Drawing.Point(64, 396);
            this.btnFight.Name = "btnFight";
            this.btnFight.Size = new System.Drawing.Size(136, 42);
            this.btnFight.TabIndex = 8;
            this.btnFight.Text = "Fight";
            this.btnFight.UseVisualStyleBackColor = false;
            this.btnFight.Click += new System.EventHandler(this.btnFight_Click);
            // 
            // btnHeal
            // 
            this.btnHeal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHeal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHeal.Location = new System.Drawing.Point(241, 396);
            this.btnHeal.Name = "btnHeal";
            this.btnHeal.Size = new System.Drawing.Size(121, 42);
            this.btnHeal.TabIndex = 9;
            this.btnHeal.Text = "Heal";
            this.btnHeal.UseVisualStyleBackColor = true;
            this.btnHeal.Click += new System.EventHandler(this.btnHeal_ClickAsync);
            // 
            // btnStun
            // 
            this.btnStun.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStun.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStun.Location = new System.Drawing.Point(409, 396);
            this.btnStun.Name = "btnStun";
            this.btnStun.Size = new System.Drawing.Size(121, 42);
            this.btnStun.TabIndex = 10;
            this.btnStun.Text = "Stun";
            this.btnStun.UseVisualStyleBackColor = true;
            this.btnStun.Click += new System.EventHandler(this.btnStun_ClickAsync);
            // 
            // btnProtect
            // 
            this.btnProtect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProtect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProtect.Location = new System.Drawing.Point(569, 396);
            this.btnProtect.Name = "btnProtect";
            this.btnProtect.Size = new System.Drawing.Size(121, 42);
            this.btnProtect.TabIndex = 11;
            this.btnProtect.Text = "Block";
            this.btnProtect.UseVisualStyleBackColor = true;
            this.btnProtect.Click += new System.EventHandler(this.btnProtect_ClickAsync);
            // 
            // textBoxDialog
            // 
            this.textBoxDialog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxDialog.Enabled = false;
            this.textBoxDialog.Location = new System.Drawing.Point(196, 31);
            this.textBoxDialog.Name = "textBoxDialog";
            this.textBoxDialog.Size = new System.Drawing.Size(192, 13);
            this.textBoxDialog.TabIndex = 12;
            this.textBoxDialog.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // picBoxBackground
            // 
            this.picBoxBackground.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxBackground.Image = ((System.Drawing.Image)(resources.GetObject("picBoxBackground.Image")));
            this.picBoxBackground.Location = new System.Drawing.Point(-6, -7);
            this.picBoxBackground.Name = "picBoxBackground";
            this.picBoxBackground.Size = new System.Drawing.Size(808, 460);
            this.picBoxBackground.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxBackground.TabIndex = 13;
            this.picBoxBackground.TabStop = false;
            // 
            // textBoxPlayerHealth
            // 
            this.textBoxPlayerHealth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxPlayerHealth.Enabled = false;
            this.textBoxPlayerHealth.Location = new System.Drawing.Point(569, 364);
            this.textBoxPlayerHealth.Name = "textBoxPlayerHealth";
            this.textBoxPlayerHealth.Size = new System.Drawing.Size(219, 13);
            this.textBoxPlayerHealth.TabIndex = 14;
            this.textBoxPlayerHealth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxDialogMonster
            // 
            this.textBoxDialogMonster.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxDialogMonster.Enabled = false;
            this.textBoxDialogMonster.Location = new System.Drawing.Point(569, 345);
            this.textBoxDialogMonster.Name = "textBoxDialogMonster";
            this.textBoxDialogMonster.Size = new System.Drawing.Size(219, 13);
            this.textBoxDialogMonster.TabIndex = 15;
            this.textBoxDialogMonster.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTurn
            // 
            this.textBoxTurn.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTurn.Enabled = false;
            this.textBoxTurn.Location = new System.Drawing.Point(12, 12);
            this.textBoxTurn.Name = "textBoxTurn";
            this.textBoxTurn.Size = new System.Drawing.Size(100, 13);
            this.textBoxTurn.TabIndex = 16;
            this.textBoxTurn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // LightAttackAnimation
            // 
            this.LightAttackAnimation.Image = ((System.Drawing.Image)(resources.GetObject("LightAttackAnimation.Image")));
            this.LightAttackAnimation.Location = new System.Drawing.Point(40, 96);
            this.LightAttackAnimation.Name = "LightAttackAnimation";
            this.LightAttackAnimation.Size = new System.Drawing.Size(480, 320);
            this.LightAttackAnimation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.LightAttackAnimation.TabIndex = 17;
            this.LightAttackAnimation.TabStop = false;
            // 
            // IdleMove
            // 
            this.IdleMove.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("IdleMove.BackgroundImage")));
            this.IdleMove.Location = new System.Drawing.Point(40, 31);
            this.IdleMove.Name = "IdleMove";
            this.IdleMove.Size = new System.Drawing.Size(480, 320);
            this.IdleMove.TabIndex = 18;
            this.IdleMove.TabStop = false;
            // 
            // HeavyAttackAnimation
            // 
            this.HeavyAttackAnimation.Image = ((System.Drawing.Image)(resources.GetObject("HeavyAttackAnimation.Image")));
            this.HeavyAttackAnimation.Location = new System.Drawing.Point(50, 38);
            this.HeavyAttackAnimation.Name = "HeavyAttackAnimation";
            this.HeavyAttackAnimation.Size = new System.Drawing.Size(480, 320);
            this.HeavyAttackAnimation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.HeavyAttackAnimation.TabIndex = 19;
            this.HeavyAttackAnimation.TabStop = false;
            // 
            // DeathAnim
            // 
            this.DeathAnim.Image = ((System.Drawing.Image)(resources.GetObject("DeathAnim.Image")));
            this.DeathAnim.Location = new System.Drawing.Point(29, 31);
            this.DeathAnim.Name = "DeathAnim";
            this.DeathAnim.Size = new System.Drawing.Size(480, 320);
            this.DeathAnim.TabIndex = 20;
            this.DeathAnim.TabStop = false;
            // 
            // Health
            // 
            this.Health.Image = ((System.Drawing.Image)(resources.GetObject("Health.Image")));
            this.Health.Location = new System.Drawing.Point(202, 131);
            this.Health.Name = "Health";
            this.Health.Size = new System.Drawing.Size(149, 111);
            this.Health.TabIndex = 21;
            this.Health.TabStop = false;
            // 
            // PlayerHitAnimation
            // 
            this.PlayerHitAnimation.Image = ((System.Drawing.Image)(resources.GetObject("PlayerHitAnimation.Image")));
            this.PlayerHitAnimation.Location = new System.Drawing.Point(-118, 24);
            this.PlayerHitAnimation.Name = "PlayerHitAnimation";
            this.PlayerHitAnimation.Size = new System.Drawing.Size(480, 320);
            this.PlayerHitAnimation.TabIndex = 22;
            this.PlayerHitAnimation.TabStop = false;
            // 
            // bossattack
            // 
            this.bossattack.Image = ((System.Drawing.Image)(resources.GetObject("bossattack.Image")));
            this.bossattack.Location = new System.Drawing.Point(-47, 38);
            this.bossattack.Name = "bossattack";
            this.bossattack.Size = new System.Drawing.Size(480, 320);
            this.bossattack.TabIndex = 23;
            this.bossattack.TabStop = false;
            // 
            // bossidle
            // 
            this.bossidle.Image = ((System.Drawing.Image)(resources.GetObject("bossidle.Image")));
            this.bossidle.Location = new System.Drawing.Point(-175, 50);
            this.bossidle.Name = "bossidle";
            this.bossidle.Size = new System.Drawing.Size(489, 320);
            this.bossidle.TabIndex = 24;
            this.bossidle.TabStop = false;
            // 
            // Bosshealth
            // 
            this.Bosshealth.Location = new System.Drawing.Point(196, 14);
            this.Bosshealth.Maximum = 1000;
            this.Bosshealth.Name = "Bosshealth";
            this.Bosshealth.Size = new System.Drawing.Size(381, 11);
            this.Bosshealth.TabIndex = 26;
            // 
            // playerhealthbar
            // 
            this.playerhealthbar.Location = new System.Drawing.Point(660, 326);
            this.playerhealthbar.Maximum = 1000;
            this.playerhealthbar.Name = "playerhealthbar";
            this.playerhealthbar.Size = new System.Drawing.Size(128, 13);
            this.playerhealthbar.TabIndex = 27;
            // 
            // ItemPanel
            // 
            this.ItemPanel.AllowDrop = true;
            this.ItemPanel.Controls.Add(this.btnDrop);
            this.ItemPanel.Controls.Add(this.btnInfo);
            this.ItemPanel.Controls.Add(this.btnUse);
            this.ItemPanel.Controls.Add(this.btnItem10);
            this.ItemPanel.Controls.Add(this.btnItem9);
            this.ItemPanel.Controls.Add(this.btnItem8);
            this.ItemPanel.Controls.Add(this.btnItem7);
            this.ItemPanel.Controls.Add(this.btnItem6);
            this.ItemPanel.Controls.Add(this.btnItem5);
            this.ItemPanel.Controls.Add(this.btnItem4);
            this.ItemPanel.Controls.Add(this.btnItem3);
            this.ItemPanel.Controls.Add(this.btnItem2);
            this.ItemPanel.Controls.Add(this.btnItem1);
            this.ItemPanel.Location = new System.Drawing.Point(588, 46);
            this.ItemPanel.Name = "ItemPanel";
            this.ItemPanel.Size = new System.Drawing.Size(200, 264);
            this.ItemPanel.TabIndex = 28;
            // 
            // btnDrop
            // 
            this.btnDrop.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnDrop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDrop.Location = new System.Drawing.Point(133, 233);
            this.btnDrop.Name = "btnDrop";
            this.btnDrop.Size = new System.Drawing.Size(56, 23);
            this.btnDrop.TabIndex = 12;
            this.btnDrop.Text = "Drop";
            this.btnDrop.UseVisualStyleBackColor = true;
            this.btnDrop.Click += new System.EventHandler(this.btnDrop_Click);
            // 
            // btnInfo
            // 
            this.btnInfo.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInfo.Location = new System.Drawing.Point(71, 233);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(56, 23);
            this.btnInfo.TabIndex = 11;
            this.btnInfo.Text = "Info";
            this.btnInfo.UseVisualStyleBackColor = true;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            // 
            // btnUse
            // 
            this.btnUse.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnUse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUse.Location = new System.Drawing.Point(9, 233);
            this.btnUse.Name = "btnUse";
            this.btnUse.Size = new System.Drawing.Size(56, 23);
            this.btnUse.TabIndex = 10;
            this.btnUse.Text = "Use";
            this.btnUse.UseVisualStyleBackColor = true;
            this.btnUse.Click += new System.EventHandler(this.btnUse_ClickAsync);
            // 
            // btnItem10
            // 
            this.btnItem10.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem10.Location = new System.Drawing.Point(5, 195);
            this.btnItem10.Name = "btnItem10";
            this.btnItem10.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem10.Size = new System.Drawing.Size(190, 23);
            this.btnItem10.TabIndex = 9;
            this.btnItem10.Text = "Item10";
            this.btnItem10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem10.UseVisualStyleBackColor = true;
            this.btnItem10.Click += new System.EventHandler(this.btnItem10_ClickAsync);
            // 
            // btnItem9
            // 
            this.btnItem9.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem9.Location = new System.Drawing.Point(5, 174);
            this.btnItem9.Name = "btnItem9";
            this.btnItem9.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem9.Size = new System.Drawing.Size(190, 23);
            this.btnItem9.TabIndex = 8;
            this.btnItem9.Text = "Item9";
            this.btnItem9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem9.UseVisualStyleBackColor = true;
            this.btnItem9.Click += new System.EventHandler(this.btnItem9_ClickAsync);
            // 
            // btnItem8
            // 
            this.btnItem8.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem8.Location = new System.Drawing.Point(5, 153);
            this.btnItem8.Name = "btnItem8";
            this.btnItem8.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem8.Size = new System.Drawing.Size(190, 23);
            this.btnItem8.TabIndex = 7;
            this.btnItem8.Text = "Item8";
            this.btnItem8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem8.UseVisualStyleBackColor = true;
            this.btnItem8.Click += new System.EventHandler(this.btnItem8_ClickAsync);
            // 
            // btnItem7
            // 
            this.btnItem7.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem7.Location = new System.Drawing.Point(5, 132);
            this.btnItem7.Name = "btnItem7";
            this.btnItem7.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem7.Size = new System.Drawing.Size(190, 23);
            this.btnItem7.TabIndex = 6;
            this.btnItem7.Text = "Item7";
            this.btnItem7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem7.UseVisualStyleBackColor = true;
            this.btnItem7.Click += new System.EventHandler(this.btnItem7_ClickAsync);
            // 
            // btnItem6
            // 
            this.btnItem6.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem6.Location = new System.Drawing.Point(5, 111);
            this.btnItem6.Name = "btnItem6";
            this.btnItem6.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem6.Size = new System.Drawing.Size(190, 23);
            this.btnItem6.TabIndex = 5;
            this.btnItem6.Text = "Item6";
            this.btnItem6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem6.UseVisualStyleBackColor = true;
            this.btnItem6.Click += new System.EventHandler(this.btnItem6_ClickAsync);
            // 
            // btnItem5
            // 
            this.btnItem5.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem5.Location = new System.Drawing.Point(5, 90);
            this.btnItem5.Name = "btnItem5";
            this.btnItem5.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem5.Size = new System.Drawing.Size(190, 23);
            this.btnItem5.TabIndex = 4;
            this.btnItem5.Text = "Item5";
            this.btnItem5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem5.UseVisualStyleBackColor = true;
            this.btnItem5.Click += new System.EventHandler(this.btnItem5_ClickAsync);
            // 
            // btnItem4
            // 
            this.btnItem4.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem4.Location = new System.Drawing.Point(5, 69);
            this.btnItem4.Name = "btnItem4";
            this.btnItem4.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem4.Size = new System.Drawing.Size(190, 23);
            this.btnItem4.TabIndex = 3;
            this.btnItem4.Text = "Item4";
            this.btnItem4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem4.UseVisualStyleBackColor = true;
            this.btnItem4.Click += new System.EventHandler(this.btnItem4_ClickAsync);
            // 
            // btnItem3
            // 
            this.btnItem3.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem3.Location = new System.Drawing.Point(5, 48);
            this.btnItem3.Name = "btnItem3";
            this.btnItem3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem3.Size = new System.Drawing.Size(190, 23);
            this.btnItem3.TabIndex = 2;
            this.btnItem3.Text = "Item3";
            this.btnItem3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem3.UseVisualStyleBackColor = true;
            this.btnItem3.Click += new System.EventHandler(this.btnItem3_ClickAsync);
            // 
            // btnItem2
            // 
            this.btnItem2.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem2.Location = new System.Drawing.Point(5, 27);
            this.btnItem2.Name = "btnItem2";
            this.btnItem2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem2.Size = new System.Drawing.Size(190, 23);
            this.btnItem2.TabIndex = 1;
            this.btnItem2.Text = "Item2";
            this.btnItem2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem2.UseVisualStyleBackColor = true;
            this.btnItem2.Click += new System.EventHandler(this.btnItem2_ClickAsync);
            // 
            // btnItem1
            // 
            this.btnItem1.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.btnItem1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItem1.Location = new System.Drawing.Point(5, 6);
            this.btnItem1.Name = "btnItem1";
            this.btnItem1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnItem1.Size = new System.Drawing.Size(190, 23);
            this.btnItem1.TabIndex = 0;
            this.btnItem1.Text = "Item1";
            this.btnItem1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnItem1.UseVisualStyleBackColor = true;
            this.btnItem1.Click += new System.EventHandler(this.btnItem1_ClickAsync);
            // 
            // btnItemMenuHandle
            // 
            this.btnItemMenuHandle.FlatAppearance.BorderSize = 0;
            this.btnItemMenuHandle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemMenuHandle.Location = new System.Drawing.Point(588, 14);
            this.btnItemMenuHandle.Name = "btnItemMenuHandle";
            this.btnItemMenuHandle.Size = new System.Drawing.Size(200, 32);
            this.btnItemMenuHandle.TabIndex = 0;
            this.btnItemMenuHandle.Text = "Sack of Items";
            this.btnItemMenuHandle.UseVisualStyleBackColor = true;
            this.btnItemMenuHandle.Click += new System.EventHandler(this.btnItemMenuHandle_Click_1);
            // 
            // bossDamaged
            // 
            this.bossDamaged.Image = ((System.Drawing.Image)(resources.GetObject("bossDamaged.Image")));
            this.bossDamaged.Location = new System.Drawing.Point(40, 46);
            this.bossDamaged.Name = "bossDamaged";
            this.bossDamaged.Size = new System.Drawing.Size(480, 320);
            this.bossDamaged.TabIndex = 29;
            this.bossDamaged.TabStop = false;
            // 
            // bossDeath
            // 
            this.bossDeath.Image = ((System.Drawing.Image)(resources.GetObject("bossDeath.Image")));
            this.bossDeath.Location = new System.Drawing.Point(48, 54);
            this.bossDeath.Name = "bossDeath";
            this.bossDeath.Size = new System.Drawing.Size(480, 320);
            this.bossDeath.TabIndex = 30;
            this.bossDeath.TabStop = false;
            // 
            // FrmBossBattle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bossDeath);
            this.Controls.Add(this.bossDamaged);
            this.Controls.Add(this.btnItemMenuHandle);
            this.Controls.Add(this.ItemPanel);
            this.Controls.Add(this.playerhealthbar);
            this.Controls.Add(this.Bosshealth);
            this.Controls.Add(this.bossidle);
            this.Controls.Add(this.bossattack);
            this.Controls.Add(this.PlayerHitAnimation);
            this.Controls.Add(this.Health);
            this.Controls.Add(this.DeathAnim);
            this.Controls.Add(this.HeavyAttackAnimation);
            this.Controls.Add(this.IdleMove);
            this.Controls.Add(this.textBoxTurn);
            this.Controls.Add(this.textBoxDialogMonster);
            this.Controls.Add(this.textBoxPlayerHealth);
            this.Controls.Add(this.textBoxDialog);
            this.Controls.Add(this.btnProtect);
            this.Controls.Add(this.btnStun);
            this.Controls.Add(this.btnHeal);
            this.Controls.Add(this.btnFight);
            this.Controls.Add(this.textBoxMonsterHealth);
            this.Controls.Add(this.btnHeavyAttack);
            this.Controls.Add(this.btnLightAttack);
            this.Controls.Add(this.LightAttackAnimation);
            this.Controls.Add(this.picBoxBackground);
            this.Name = "FrmBossBattle";
            this.Text = "Fight!";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBackground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LightAttackAnimation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IdleMove)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeavyAttackAnimation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DeathAnim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Health)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHitAnimation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossattack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossidle)).EndInit();
            this.ItemPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bossDamaged)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossDeath)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLightAttack;
        private System.Windows.Forms.Button btnHeavyAttack;
        private System.Windows.Forms.TextBox textBoxMonsterHealth;
        private System.Windows.Forms.Button btnFight;
        private System.Windows.Forms.Button btnHeal;
        private System.Windows.Forms.Button btnStun;
        private System.Windows.Forms.Button btnProtect;
        private System.Windows.Forms.TextBox textBoxDialog;
        private System.Windows.Forms.PictureBox picBoxBackground;
        private System.Windows.Forms.TextBox textBoxPlayerHealth;
        private System.Windows.Forms.TextBox textBoxDialogMonster;
        private System.Windows.Forms.TextBox textBoxTurn;
        private System.Windows.Forms.PictureBox LightAttackAnimation;
        private System.Windows.Forms.PictureBox IdleMove;
        private System.Windows.Forms.PictureBox HeavyAttackAnimation;
        private System.Windows.Forms.PictureBox DeathAnim;
        private System.Windows.Forms.PictureBox Health;
        private System.Windows.Forms.PictureBox PlayerHitAnimation;
        private System.Windows.Forms.PictureBox bossattack;
        private System.Windows.Forms.PictureBox bossidle;
        private System.Windows.Forms.ProgressBar Bosshealth;
        private System.Windows.Forms.ProgressBar playerhealthbar;
        private System.Windows.Forms.Panel ItemPanel;
        private System.Windows.Forms.Button btnItemMenuHandle;
        private System.Windows.Forms.Button btnItem1;
        private System.Windows.Forms.Button btnItem2;
        private System.Windows.Forms.Button btnItem4;
        private System.Windows.Forms.Button btnItem3;
        private System.Windows.Forms.Button btnItem10;
        private System.Windows.Forms.Button btnItem9;
        private System.Windows.Forms.Button btnItem8;
        private System.Windows.Forms.Button btnItem7;
        private System.Windows.Forms.Button btnItem6;
        private System.Windows.Forms.Button btnItem5;
        private System.Windows.Forms.Button btnDrop;
        private System.Windows.Forms.Button btnInfo;
        private System.Windows.Forms.Button btnUse;
        private System.Windows.Forms.PictureBox bossDamaged;
        private System.Windows.Forms.PictureBox bossDeath;
    }
}

