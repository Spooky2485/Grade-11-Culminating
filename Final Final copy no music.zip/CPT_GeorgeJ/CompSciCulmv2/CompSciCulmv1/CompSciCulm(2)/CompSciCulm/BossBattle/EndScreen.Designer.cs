﻿namespace BossBattle
{
    partial class EndScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EndScreen));
            this.End = new System.Windows.Forms.Label();
            this.btnLB = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtboxLB = new System.Windows.Forms.TextBox();
            this.txtboxName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // End
            // 
            this.End.AutoSize = true;
            this.End.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.End.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.End.ForeColor = System.Drawing.SystemColors.Control;
            this.End.Location = new System.Drawing.Point(201, 26);
            this.End.Name = "End";
            this.End.Size = new System.Drawing.Size(380, 31);
            this.End.TabIndex = 0;
            this.End.Text = "Thanks For Playing Our Game";
            // 
            // btnLB
            // 
            this.btnLB.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnLB.ForeColor = System.Drawing.SystemColors.Control;
            this.btnLB.Location = new System.Drawing.Point(283, 218);
            this.btnLB.Name = "btnLB";
            this.btnLB.Size = new System.Drawing.Size(218, 43);
            this.btnLB.TabIndex = 1;
            this.btnLB.Text = "Leaderboard";
            this.btnLB.UseVisualStyleBackColor = false;
            this.btnLB.Click += new System.EventHandler(this.btnLB_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnMenu.ForeColor = System.Drawing.SystemColors.Control;
            this.btnMenu.Location = new System.Drawing.Point(283, 279);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(218, 43);
            this.btnMenu.TabIndex = 2;
            this.btnMenu.Text = "Quit to Main Menu";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnQuit.ForeColor = System.Drawing.SystemColors.Control;
            this.btnQuit.Location = new System.Drawing.Point(283, 337);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(218, 42);
            this.btnQuit.TabIndex = 3;
            this.btnQuit.Text = "Quit to Desktop";
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(293, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 31);
            this.label1.TabIndex = 4;
            this.label1.Text = "Submit Name";
            // 
            // txtboxLB
            // 
            this.txtboxLB.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txtboxLB.ForeColor = System.Drawing.SystemColors.Window;
            this.txtboxLB.Location = new System.Drawing.Point(535, 154);
            this.txtboxLB.Multiline = true;
            this.txtboxLB.Name = "txtboxLB";
            this.txtboxLB.ReadOnly = true;
            this.txtboxLB.Size = new System.Drawing.Size(155, 237);
            this.txtboxLB.TabIndex = 5;
            this.txtboxLB.Visible = false;
            // 
            // txtboxName
            // 
            this.txtboxName.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtboxName.ForeColor = System.Drawing.SystemColors.Window;
            this.txtboxName.Location = new System.Drawing.Point(309, 145);
            this.txtboxName.Name = "txtboxName";
            this.txtboxName.Size = new System.Drawing.Size(162, 20);
            this.txtboxName.TabIndex = 6;
            // 
            // EndScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtboxName);
            this.Controls.Add(this.txtboxLB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.btnLB);
            this.Controls.Add(this.End);
            this.Name = "EndScreen";
            this.Text = "EndScreen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label End;
        private System.Windows.Forms.Button btnLB;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtboxLB;
        private System.Windows.Forms.TextBox txtboxName;
    }
}