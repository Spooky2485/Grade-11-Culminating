﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;


namespace BossBattle
{
    public partial class FrmBossBattle : Form
    { // HEADER : Names : Lucas, Jaeden, Jolyn, Logan, Sadeen, Date : February 3rd, 2022, Program Name : Overlord, Program Description : A video game for a boss fight.

        //EXTRA CITATION : As we used 'await' many times in our code, we weren't able to cite them all, but we figured out how to do await here : https://stackoverflow.com/questions/35735655/what-does-await-do-in-this-function

        string[] Damage = { "a", "a", "a", "a,", "a", "a", "a", "a", "a", "a" }; //Sample Array used for later code.
        string buttonchecker; // String variable for a future button checker.
        bool StrongerAxeHilt = false; // Boolean variable.
        bool ThrowablePoison = false; // Boolean variable.
        bool PotionofExtraDamage = false; // Boolean variable.
        bool Selectedbutton = false; // Boolean variable.
        int ButtonSelect; // Integer variable.
        double monsterHealth = 1000; // Monster health is set to 1000, this will be used for subtraction.
        double monsterHealthOg = 1000; // Monster health is set to 1000.
        double playerHealth = 1000; // Player health is set to 1000, this will be used for subtraction.
        double PlayerHealthOg = 1000; // Player health is set to 1000.
        int Turn = 1; // Integer variable to calculate turn number. 
        int Num1 = 2; // Integer variable.
        int Num3 = 2; // Integer variable.
        double MonsterAccuracy = 55; // Double variable for calculating monster accuracy.
        int TurnCopy; // Integer variable for determining turn copy.
        double BlockDmg = 0; // Double variable for calculating the block multiplier.
        double BossSwordAttack; // Double variable for calculating the Overlord's sword attack count.
        int itemsclick = 0; // Integer variable.
        int Itemchoice; // Integer variable.
        string[] line = { "a", "a", "a", "a,", "a", "a", "a", "a", "a", "a" }; // A sample array that the program will overwrite later.
        double NewMonsterAccuracy = 1; // Double variable for calculating accuracy.
        /* private void FrmBossBattle_Load(object sender, EventArgs e)
         {
             BossMusic.Play();
         }
         */
        //set up components
        public FrmBossBattle()
        {

            InitializeComponent(); // Initialies components of the form.
            BlockDmg = 0; // Block damage multiplier is set to 0.
            Button[] sackofItems = { btnItem1, btnItem2, btnItem3, btnItem4, btnItem5, btnItem6, btnItem7, btnItem8, btnItem9, btnItem10 }; // A collection of all the buttons labelled as 'items' in the item panel.
            playerhealthbar.Value = 1000; // The original value of the Player's health bar displayed as a progress bar.
            Bosshealth.Value = 1000; // The original value of the Boss's health bar displayed as a progress bar.
            btnLightAttack.Visible = false; // The Light attack button doesn't appear until the Player clicks 'fight'.
            btnHeavyAttack.Visible = false; // The Heavy attack button doesn't appear until the Player clicks 'fight'.
            textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg; // A display for the player health in text.
            textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg; // A display for the monster health in text.



            picBoxBackground.Controls.Add(IdleMove); // IdleMove added to background
            IdleMove.Location = new Point(-50, 105); // Location is validated
            IdleMove.BackColor = Color.Transparent; // Transparency is validated
            IdleMove.Visible = true; // The image for the idle player is not visible. 


            picBoxBackground.Controls.Add(bossidle); // Added idle animation.
            bossidle.BackColor = Color.Transparent; // Declares transparency/color.
            bossidle.Location = new Point(368, 105); // Declares location.
            bossidle.Visible = true; // Declares visibility as true of idle animation.



            foreach (var item in sackofItems) // This makes it so that the buttons inside our array are temporarily invisible.
            {
                item.Visible = false; // All buttons in the array will be invisible.
            }
            ItemPanel.Visible = false; // The panel for the sack of items is invisible.
            bossDamaged.Visible = false; //The animation for the boss being hit is not visible.
            DeathAnim.Visible = false; // The death animation is not visible.
            LightAttackAnimation.Visible = false; // The attack animation is not visible.
            HeavyAttackAnimation.Visible = false;// The attack animation is not visible.
            Health.Visible = false; // The Health potion animation is not visible.
            PlayerHitAnimation.Visible = false; // The player hit animation is not visible.
            bossattack.Visible = false; // The boss attack animation is not visible.
            bossDeath.Visible = false; // The boss death animation is not visible. 
        }

        public void MonsterAccuracyCheck() // Function. // The Overlord's accuracy function is displayed below.
        {
            MonsterAccuracy = 30 * NewMonsterAccuracy; // The Overlord's accuracy is calculated here.
        }
        public void MonsterDamageCheck() // The Overlord's damage function is displayed below.
        {
            BossSwordAttack = (BossSwordAttack * 0.5) + (BossSwordAttack * BlockDmg); // The Overlord's damage is calculated here.
        }

        public async void BossHit() // Function. // The Overlord animation for being hit is carried below.
        {
            picBoxBackground.Controls.Remove(bossidle); // The picture box control removes the Overlord idle animation as a child.
            picBoxBackground.Controls.Add(bossDamaged); // The picture box control adds the Overlord damage animation as a child.
            bossDamaged.Location = new Point(368, 105); // The location of the damaged boss animation is displayed.
            bossDamaged.BackColor = Color.Transparent; // The transparency of the damaged boss animation is displayed. 
            bossDamaged.Visible = true; // The visibility of the damaged boss animation is true.
            await Task.Delay(1400); // Following code is delayed by 1.4 seconds or 1400 miliseconds.
            bossattack.Visible = false; // The visibility of the damaged boss animation is false. 
            picBoxBackground.Controls.Remove(bossDamaged);
            IdleAnim1();
        }
        public async void AttackAnimLightAttackAsync() // Function.
        {
            picBoxBackground.Controls.Remove(IdleMove); // Removes idle animation.
            picBoxBackground.Controls.Add(LightAttackAnimation); // Adds light attack animation.
            LightAttackAnimation.Location = new Point(-50, 105); // Declares location.
            LightAttackAnimation.BackColor = Color.Transparent; // Declares color/transparency.
            LightAttackAnimation.Visible = true; // Declares visibility as true of light attack animation.
            await Task.Delay(1750); // 1.75 second delay.
            LightAttackAnimation.Visible = false; // Declares visibility as false of light attack animation.
            picBoxBackground.Controls.Remove(LightAttackAnimation); // Removes light attack anim since it has played out.
            IdleAnim2(); // Jumps back to idle animation function.
        }

        public async void IdleAnim2() // Function.
        {
            picBoxBackground.Controls.Add(IdleMove); // Added idle animation.
            IdleMove.Location = new Point(-50, 105); // Declares location.
            IdleMove.BackColor = Color.Transparent; // Declares transparency/color.
            IdleMove.Visible = true; // Declares visibility as true of idle animation.
        }

        public async void AttackAnimHeavyAttack() // Function.
        {
            picBoxBackground.Controls.Remove(IdleMove);// Picture box control removes an animation.
            picBoxBackground.Controls.Add(HeavyAttackAnimation);// Picture box control adds an animation.
            HeavyAttackAnimation.Location = new Point(-50, 105);// Location of animation is set.
            HeavyAttackAnimation.BackColor = Color.Transparent;// Color of animation background is null.
            HeavyAttackAnimation.Visible = true;// Animation is visible for 1.75 seconds.
            await Task.Delay(1750); 
            HeavyAttackAnimation.Visible = false;// Animation is no longer visible.
            picBoxBackground.Controls.Remove(HeavyAttackAnimation);// Picture box control removes an animation.
            IdleAnim2(); // Idle animation function.
        }

        public async void BossDeathAnimation() // Function.
        {
            picBoxBackground.Controls.Remove(bossidle); // Picture box control removes an animation.
            picBoxBackground.Controls.Add(bossDeath); // Picture box control adds an animation.
            bossDeath.Location = new Point(-50, 105); // Location of animation is set.
            bossDeath.BackColor = Color.Transparent; // Color of animation background is null.
            bossDeath.Visible = true; // Animation is visible for 0.9 seconds.
            await Task.Delay(900);
            bossDeath.Visible = false; // Animation is no longer visible.
            picBoxBackground.Controls.Remove(bossDeath); // Picture box control removes an animation.
        }

        public async void DeathAnimation() // Function.
        {
            picBoxBackground.Controls.Remove(IdleMove);// Picture box control removes an animation.
            picBoxBackground.Controls.Add(DeathAnim);// Picture box control adds an animation.
            DeathAnim.Location = new Point(-50, 105);// Location of animation is set.
            DeathAnim.BackColor = Color.Transparent;// Color of animation background is null.
            DeathAnim.Visible = true;// Animation is visible for 0.9 seconds.
            await Task.Delay(900);
            IdleMove.Visible = false;// Animation is no longer visible.
            picBoxBackground.Controls.Remove(DeathAnim);// Picture box control removes an animation.
        }

        public async void HealthPotion() // Function.
        {
            picBoxBackground.Controls.Add(Health);// Picture box control removes an animation.
            Health.BringToFront(); // Animation is brought to front.
            Health.Location = new Point(110, 139); // Location of animation is set.
            Health.BackColor = Color.Transparent;// Color of animation background is null.
            Health.Visible = true;// Animation is visible for 0.9 seconds.
            await Task.Delay(900);
            Health.Visible = false;// Animation is no longer visible.
            picBoxBackground.Controls.Remove(Health);// Picture box control removes an animation.
        }

        public async void PlayerHit()
        {
            picBoxBackground.Controls.Remove(IdleMove);// Picture box control removes an animation.
            picBoxBackground.Controls.Add(PlayerHitAnimation);// Picture box control adds an animation.
            PlayerHitAnimation.Location = new Point(-50, 105);// Location of animation is set.
            PlayerHitAnimation.BackColor = Color.Transparent;// Color of animation background is null.
            PlayerHitAnimation.Visible = true;// Animation is visible for 1.4 seconds.
            await Task.Delay(1400);
            PlayerHitAnimation.Visible = false;// Animation is no longer visible.
            picBoxBackground.Controls.Remove(PlayerHitAnimation);// Picture box control removes an animation.
            IdleAnim2(); // Idle animation function.
        }

        public async void IdleAnim1()
        {
            picBoxBackground.Controls.Add(bossidle); // Added idle animation
            bossidle.Location = new Point(368, 105); // Declares location
            bossidle.BackColor = Color.Transparent; // Declares transparency/color
            bossidle.Visible = true; // Declares visibility as true of idle anim
        }


        public async void BossAttack1()
        {
            picBoxBackground.Controls.Remove(bossidle);// Picture box control removes an animation.
            picBoxBackground.Controls.Add(bossattack);// Picture box control adds an animation.
            bossattack.Location = new Point(368, 105);// Location of animation is set.
            bossattack.BackColor = Color.Transparent;// Color of animation background is null.
            bossattack.Visible = true;// Animation is visible for 1.4 seconds.
            await Task.Delay(1400);
            bossattack.Visible = false;// Animation is no longer visible.
            picBoxBackground.Controls.Remove(bossattack);// Picture box control removes an animation.
            IdleAnim1();// Idle animation function.
        }

        public void AddToPictureBox(PictureBox child_PB, PictureBox parent_PB) // Picture box control check function.
        {
            Point ptChildScreen = child_PB.PointToScreen(new Point(0, 0));// Location of animations are set.
            parent_PB.Controls.Add(child_PB);// Picture box control adds child animation.
            child_PB.Location = parent_PB.PointToClient(ptChildScreen);// Picture box control points to the animation.
            child_PB.BackColor = Color.Transparent; // Color of animation background is null.
            child_PB.Visible = true;// Animation is visible for 1.4 seconds.
        }

        public void DeathCheck() // Death check function.
        {
            if (monsterHealth < 0) // If statement for when the monster health goes below the value of 0. 
            {
                StreamWriter sw = new StreamWriter(@"LB.txt", true); // Streamwriter is set on a text file in the bin -> debug, known as LB.txt.
                sw.Write("\n" + textBoxTurn.Text); // Writes the final turn number at the end of the match and stores it in the text file.
                sw.Close(); // Closes the streamwriter.

                BossDeathAnimation(); // A function for an animation plays, this animation contains pictures for the Overlord's death.
                MessageBox.Show("You Win!"); // Message box appears congratulating the player on their victory.
                var EndScreens = new EndScreen(); // The 'end screen' form is stored in a variable.
                EndScreens.Show(); // // The end screen form is shown through the previously stored variable.
                this.Hide(); // The boss battle form is hidden from the user.
            }
            if (playerHealth < 0)
            {
                StreamWriter sw = new StreamWriter(@"LB.txt", true);// Streamwriter is set on a text file in the bin -> debug, known as LB.txt.
                sw.Write("\n" + textBoxTurn.Text);// Writes the final turn number at the end of the match and stores it in the text file.
                sw.Close();// Closes the streamwriter.

                DeathAnimation();// A function for an animation plays, this animation contains pictures for the Player's death.
                MessageBox.Show("You Lose.");// Message box appears congratulating the player on their failure.
                var EndScreens = new EndScreen();// The 'end screen' form is stored in a variable.
                EndScreens.Show();// The end screen form is shown through the previously stored variable.
                this.Hide(); // The boss battle form is hidden from the user.
            }
        }

        

        //MonsterAi
        public async Task AiAttackAsync() // Function for the Overlord's attack.
        {
            await Task.Delay(1000); // Task is delayed by 1 second.

            textBoxDialog.Text = ""; // The player dialog box is set to empty.
            Random SwordSliceChance = new Random(Guid.NewGuid().GetHashCode()); // Generates a random. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
            int SwordSliceDMG = SwordSliceChance.Next(0, 101); // The random variable generates a random number from an indicated range.

            if (SwordSliceDMG <= MonsterAccuracy) //if the generated fireballchance is greater than the monster's accuracy, then the attack will follow thrugh.
            {
                Random SwordNum = new Random(Guid.NewGuid().GetHashCode()); // Generates a random. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
                BossSwordAttack = SwordNum.Next(70, 111); // The random variable generates a random number from an indicated range.

                if (SwordSliceDMG <= 9) // The number generated by the random variable is now used for an if statement; if the number is less than or equal to 0, a critical hit statement and effect plays out.
                {
                    await Task.Delay(100);// Task is delayed by 0.1 second.
                    try // Try & catch is used for error catching here.
                    {
                        MonsterDamageCheck(); // Function for the monster damage multiplier is played out.
                        BossAttack1(); // Function for the Overlord attack animation is played out.
                        playerhealthbar.Value -= (int)(BossSwordAttack * 1.25); // The player's health bar is decreased by a set amount.
                        PlayerHit(); // Function for the Player hit animation is played out.
                        playerHealth -= (BossSwordAttack * 1.25); // The player's health number is decreased by a set amount.
                        textBoxDialogMonster.Text = "Critical Hit : " + (BossSwordAttack * 1.25); // The damage dealt is displayed in the text box.
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;// The player's new health number is displayed.

                    }
                    catch// Try & catch is used for error catching here.
                    {
                        playerhealthbar.Value = 0; // If the player's health bar goes below 0 or into a negative number, the program catches the error and makes the health bar value set to 0.
                        MonsterDamageCheck();// Function for the monster damage multiplier is played out.
                        BossAttack1();// Function for the Overlord attack animation is played out.
                        PlayerHit();// Function for the Player hit animation is played out.
                        playerHealth = 0;// The player's health number is now a set to 0.
                        textBoxDialogMonster.Text = "Critical Hit : " + (BossSwordAttack * 1.25);// The damage dealt is displayed in the text box.
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;// The player's new health number is displayed.

                    }
                    
                }
                else if (SwordSliceDMG > 9) // If the random number generated previously is above 9, the following if statement plays out.
                {
                    await Task.Delay(100); // Task is delayed by 0.1 seconds.
                    try// Try & catch is used for error catching here.
                    {
                       
                        MonsterDamageCheck();// Function for the monster damage multiplier is played out.
                        playerhealthbar.Value -= (int)(BossSwordAttack); // The player's health bar is decreased by a set amount.
                        BossAttack1();// Function for the Overlord attack animation is played out.
                        PlayerHit();// Function for the Player hit animation is played out.
                        playerHealth -= BossSwordAttack;// The player's health number is decreased by a set amount
                        textBoxDialogMonster.Text = BossSwordAttack.ToString();// The damage dealt is displayed in the text box.
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;// The player's new health number is displayed.

                    }
                    catch// Try & catch is used for error catching here.
                    {
                        playerhealthbar.Value = 0;// If the player's health bar goes below 0 or into a negative number, the program catches the error and makes the health bar value set to 0.
                        MonsterDamageCheck();// Function for the monster damage multiplier is played out
                        BossAttack1();// Function for the Overlord attack animation is played out.
                        PlayerHit();// Function for the Player hit animation is played out.
                        textBoxDialogMonster.Text = BossSwordAttack.ToString();// The damage dealt is displayed in the text box.
                        playerHealth = 0;// The player's health number is now a set to 0.
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;// The player's new health number is displayed.

                    }
                }
            }

            else if (SwordSliceDMG >= MonsterAccuracy) // If the random number generator exceeds the Overlord's accuracy number, the following if statement plays.
            {
                textBoxDialogMonster.Text = "Missed";// The textbox displays 'missed'.
                textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;// The player's new health number is displayed.
            }
        }

        //fight select
        private void btnFight_Click(object sender, EventArgs e) // Function for when the user clicks Fight.
        {
            AddToPictureBox(IdleMove, picBoxBackground); // Checks that the Player idle animation is added to picture box control as a child.
            AddToPictureBox(bossidle, picBoxBackground);// Checks that the Overlord idle animation is added to picture box control as a child.

            Num1 = Num1 % 2;// If the number is odd, the light and heavy attack buttons do not show. If the number is even, they do.
            if (Num1 > 0)// If the number is odd, the light and heavy attack buttons do not show. If the number is even, they do.
            {
                btnLightAttack.Visible = false; // Button is not visible.
                btnHeavyAttack.Visible = false;// Button is not visible.
            }
            else
            {
                btnLightAttack.Visible = true;// Button is visible.
                btnHeavyAttack.Visible = true;// Button is visible.
            }
            Num1 += 1; // Adds one to the number variable so that the user can make the specific attack buttons visible and invisible by clicking the fight button. 

        }


        //Heavy attack
        private async void btnHeavyAttack_ClickAsync(object sender, EventArgs e)// Function for the player's heavy attack.
        {
            btnFight.Visible = false; // Fight button is invisible when this function is playing to give the illusion of a delay.
            btnHeavyAttack.Visible = false;// Heavy attack button is invisible when this function is playing to give the illusion of a delay.
            btnLightAttack.Visible = false;// Light attack  button is invisible when this function is playing to give the illusion of a delay.
            btnStun.Visible = false;// Stun button is invisible when this function is playing to give the illusion of a delay.
            btnHeal.Visible = false;// Heal button is invisible when this function is playing to give the illusion of a delay.
            btnProtect.Visible = false;// Protect button is invisible when this function is playing to give the illusion of a delay.
            await Task.Delay(500); // Task delay for 0.5 seconds.
            textBoxDialog.Text = ""; // Player's dialog box is empty.
            Random HRamNumChance = new Random(Guid.NewGuid().GetHashCode()); // Generates a random. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
            int HeavyAttackChance = HRamNumChance.Next(0, 101); // A random number is generated from the specified range.

            if (HeavyAttackChance <= 60)// If the number is below or equal to 60, the following if statement plays out.
            {
                Random HRamNum = new Random(Guid.NewGuid().GetHashCode()); // Generates a random. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
                double HeavyAttack = HRamNum.Next(40, 81); // A random number is generated from the specified range.
                if (HeavyAttackChance <= 9 && PotionofExtraDamage == false) // If the random number is below or equal to nine, and the boolean variable for extra damage is false, the following if statement plays out. The player can enable extra damage boolean variable as true by using the potion in the item sack.
                {
                    try // Try & catch is used for error checking.
                    {
                        Bosshealth.Value -= (int)(HeavyAttack * 1.25); // The Overlord's health bar is now set to a specific amount.

                        AttackAnimHeavyAttack();// Function for the player attack animation is played out.
                        BossHit(); // Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - (HeavyAttack * 1.25); // Overlord health is decreased to a set amount.
                        textBoxDialog.Text = "Critical Hit : " + (HeavyAttack * 1.25); // The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg; // The Overlord's new health is displayed in a text box.
                    }
                    catch// Try & catch is used for error checking.
                    {
                        Bosshealth.Value = 0; // If the Overlord's health bar goes below 0 or into a negative number, the program catches the error and makes the health bar value set to 0.

                        AttackAnimHeavyAttack(); // Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = 0;// Overlord health is decreased to a set amount.
                        textBoxDialog.Text = "Critical Hit : " + (HeavyAttack * 1.25);// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;// The Overlord's new health is displayed in a text box.
                    }
                }
                else if (HeavyAttackChance <= 9 && PotionofExtraDamage == true)  // If the random number is below or equal to nine, and the boolean variable for extra damage is true, the following if statement plays out. The player can enable extra damage boolean variable as true by using the potion in the item sack.
                {
                    try// Try & catch is used for error checking.
                    {
                        Bosshealth.Value -= (int)(HeavyAttack * 2);// The Overlord's health bar is now set to a specific amount.

                        AttackAnimHeavyAttack();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - (HeavyAttack * 2);// Overlord health is decreased to a set amount.
                        textBoxDialog.Text = "Critical Hit! " + (HeavyAttack * 2);// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;// The Overlord's new health is displayed in a text box.
                    }
                    catch// Try & catch is used for error checking.
                    {
                        Bosshealth.Value = 0;// If the Overlord's health bar goes below 0 or into a negative number, the program catches the error and makes the health bar value set to 0.

                        AttackAnimHeavyAttack();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = 0; // Overlord health is decreased to a set amount.
                        textBoxDialog.Text = "Critical Hit :" + (HeavyAttack * 2);// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;// The Overlord's new health is displayed in a text box.
                    }
                }
                else if (HeavyAttackChance > 9 && StrongerAxeHilt == true)// If the random number is below or equal to nine, and the boolean variable for a stronger axe hilt is true, the following if statement plays out. The player can enable a stronger axe hilt in the item sack feature.
                {
                    try// Try & catch is used for error checking.
                    {
                        Bosshealth.Value -= (int)(HeavyAttack + 50);// The Overlord's health bar is now set to a specific amount.
                        AttackAnimHeavyAttack();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - (HeavyAttack + 50);// Overlord health is decreased to a set amount.
                        textBoxDialog.Text = "Regular Hit : " + (HeavyAttack + 50).ToString();// The damage dealt is displayed in a text box.
                       textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;// The Overlord's new health is displayed in a text box.

                    }
                    catch// Try & catch is used for error checking.
                    {
                        Bosshealth.Value = 0;// The Overlord's health bar is now set to a specific amount.
                        AttackAnimHeavyAttack();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = 0;// Overlord health is decreased to a set amount.
                        textBoxDialog.Text = "Regular Hit : " + (HeavyAttack + 50).ToString();// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;// The Overlord's new health is displayed in a text box.
                    }

                }
                else if (HeavyAttackChance > 9 && HeavyAttackChance <= 60 && StrongerAxeHilt == false)// If the random number is below or equal to nine, and the boolean variable for a stronger axe hilt is false, the following if statement plays out. The player can enable a stronger axe hilt in the item sack feature.
                {
                    try// Try & catch is used for error checking.
                    {
                        Bosshealth.Value -= (int)(HeavyAttack);// The Overlord's health bar is now set to a specific amount.
                        AttackAnimHeavyAttack();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - HeavyAttack;// Overlord health is decreased to a set amount.
                        textBoxDialog.Text = "Regular Hit : " + HeavyAttack.ToString();// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;// The Overlord's new health is displayed in a text box.
                    }
                    catch// Try & catch is used for error checking.
                    {
                        Bosshealth.Value = 0;// The Overlord's health bar is now set to a specific amount.
                        AttackAnimHeavyAttack();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = 0;// Overlord health is decreased to a set amount.
                        textBoxDialog.Text = "Regular Hit : " + HeavyAttack.ToString();// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;// The Overlord's new health is displayed in a text box.
                    }
                    
                }

            }
            else if (HeavyAttackChance > 60)// If the random number generator exceeds the Overlord's accuracy number, the following if statement plays.
            {
                textBoxDialog.Text = "You Missed";// The textbox displays 'missed'.
                textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;// The player's new health number is displayed.
            }
            await Task.Delay(1000); // Task is delayed by 1 second.
            MonsterAccuracyCheck(); // Function for the Overlord's accuracy check is played here.
            await AiAttackAsync();// Awaits the AI attack function.
            await Task.Delay(1100); // Task is delayed by 1.1 seconds.
            DeathCheck();//Death Check function is played here.
            textBoxTurn.Text = "Turn " + (Turn.ToString()); // Textbox with turn number is written here.
            Turn++;//Turn number goes up by one.
            btnFight.Visible = true; // Fight button is visible.
            Num1 += 1; // Variable for light attack and heavy attack visibility is increased by one.
            btnStun.Visible = true;// Stun button is visible.
            btnHeal.Visible = true;// Heal button is visible.
            btnProtect.Visible = true;// Protect button is visible.
        }

        //Light attack
        private async void btnLightAttack_ClickAsync(object sender, EventArgs e)// Function for the player's light attack.
        {
            // initiates animation

            btnFight.Visible = false;// Fight button is invisible.
            btnHeavyAttack.Visible = false;// Heavy attack button is invisible.
            btnLightAttack.Visible = false;// Light attack button is invisible.
            btnStun.Visible = false;// Stun button is invisible.
            btnHeal.Visible = false;// Heal button is invisible.
            btnProtect.Visible = false;// Protect button is invisible.
            await Task.Delay(500); // Task delay by 0.5 seconds.
            //TimeSpan timeout = new TimeSpan(0, 0, 1);
            textBoxDialog.Text = ""; // Text box display is set to empty.
            Random LRamNumChance = new Random(Guid.NewGuid().GetHashCode());// Generates a random. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
            int LightAttackChance = LRamNumChance.Next(0, 101); // Random variable generates a random number.
            //Thread.Sleep(timeout);

            if (LightAttackChance <= 95)// If the random number generated previously is less than 95, the following if statement plays out.
            {
                Random LRamNum = new Random(); // Generates a random. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
                double LightAttack = LRamNum.Next(30, 51);// Random variable generates a random number.
                if (LightAttackChance <= 14.25 && PotionofExtraDamage == false)//If the generated light attack is less than or equal to 14.25 and the boolean variable is false, the following if statement will play out.
                {
                    try// Try & catch is used for error checking.
                    {
                        Bosshealth.Value -= (int)(LightAttack * 1.25);// The Overlord's health bar is now set to a specific amount.
                        AttackAnimLightAttackAsync();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - (LightAttack * 1.25);// The Overlord's health number is decreased by a set amount.
                        textBoxDialog.Text = "Critical Hit : " + (LightAttack * 1.25); // The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;// The Overlord's new health number is displayed in a text box.
                    }
                    catch// Try & catch is used for error checking.
                    {
                        Bosshealth.Value = 0; // If the player's health bar goes below 0 or into a negative number, the program catches the error and makes the health bar value set to 0.
                        AttackAnimLightAttackAsync();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - (LightAttack * 1.25);// The Overlord's health number is decreased by a set amount.
                        textBoxDialog.Text = "Critical Hit : " + (LightAttack * 1.25);  // The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;// The Overlord's new health number is displayed in a text box.
                    }
                   

                }
                else if (LightAttackChance <= 14.25 && PotionofExtraDamage == true)//If the generated light attack is less than or equal to 14.25 and the boolean variable is true, the following if statement will play out.
                {
                    try// Try & catch is used for error checking.
                    {
                        Bosshealth.Value -= (int)(LightAttack * 2);// The Overlord's health bar is now set to a specific amount.
                        AttackAnimLightAttackAsync();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - (LightAttack * 2);// The Overlord's health number is decreased by a set amount.
                        textBoxDialog.Text = "Critical Hit : " + (LightAttack * 2);// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;// The Overlord's new health number is displayed in a text box.
                    }
                    catch// Try & catch is used for error checking.
                    {
                        Bosshealth.Value = 0;// The Overlord's health bar is now set to a specific amount.
                        AttackAnimLightAttackAsync();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - (LightAttack * 1.25);// The Overlord's health number is decreased by a set amount.
                        textBoxDialog.Text = "Critical Hit : " + (LightAttack * 2);// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;// The Overlord's new health number is displayed in a text box.
                    }
                    
                }

                else if (LightAttackChance > 14.25)//If the generated light attack is greater than 14.25, the following if statement will play out.
                {
                    try// Try & catch is used for error checking.
                    {
                        Bosshealth.Value -= (int)(LightAttack);// The Overlord's health bar is now set to a specific amount.
                        AttackAnimLightAttackAsync();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - LightAttack;// The Overlord's health number is decreased by a set amount.
                        textBoxDialog.Text = "Regular Hit : " + (LightAttack);// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;// The Overlord's new health number is displayed in a text box.
                    }
                    catch// Try & catch is used for error checking.
                    {
                        Bosshealth.Value = 0;// The Overlord's health bar is now set to a specific amount.
                        AttackAnimLightAttackAsync();// Function for the player attack animation is played out.
                        BossHit();// Function for the Overlord being hit in animation is played out.
                        monsterHealth = monsterHealth - LightAttack;// The Overlord's health number is decreased by a set amount.
                        textBoxDialog.Text = "Regular Hit : " + (LightAttack);// The damage dealt is displayed in a text box.
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;// The Overlord's new health number is displayed in a text box.
                    }
                   
                }
            }

            else if(LightAttackChance > 95) // If the light attack is greater than 95, the attack misses.
            {
                textBoxDialog.Text = "You Missed";// Dialog box displays 'you missed'.
                textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg; ;// The Overlord's new health number is displayed in a text box.
            }
            await Task.Delay(1000); // Task is delayed by 1 second.
            MonsterAccuracyCheck(); // Function for the monster accuracy check is started here.

            await AiAttackAsync();// Awaits AI attack function.
            await Task.Delay(1100); // Task is delayed by 1.1 seconds.
            DeathCheck();//Death Check function is played here.
            textBoxTurn.Text = "Turn " + (Turn.ToString()); // The updated turn number is now written in the text box.
            Turn++;//Turn number goes up by 1.
            btnFight.Visible = true; // The fight button is now visible.
            Num1 += 1; // Variable for light attack and heavy attack visibility is increased by one.
            btnStun.Visible = true; // The stun button is now visible.
            btnHeal.Visible = true;// The heal button is now visible.
            btnProtect.Visible = true;// The protect button is now visible.

        }
        //Heal
        private async void btnHeal_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false; // The fight button is now invisible.
            btnHeavyAttack.Visible = false;// The heavy attack button is now invisible.
            btnLightAttack.Visible = false;// The light attack button is now invisible.
            btnStun.Visible = false;// The stun button is now invisible.
            btnHeal.Visible = false;// The heal button is now invisible.
            btnProtect.Visible = false;// The protect button is now invisible.
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HealRamNumChance = new Random(Guid.NewGuid().GetHashCode()); // Generates a random. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
            int HealChance = HealRamNumChance.Next(0, 101); // Heal chance number is generated from a specified range.
            if (playerHealth == 1000) // If the player's health is 1000, the player isn't healed.
            {
                MessageBox.Show("Your health must be below or equal to 800 points in order to Heal.");
                textBoxDialog.Text = "INVALID ; MAX HP";
                textBoxDialogMonster.Text = "INVALID ;  HP";
            }
            else if ((playerHealth + 200) > 1000)// If the player's health is not below 800, the player isn't healed.
            {
                MessageBox.Show("Your health must be below or equal to 800 points in order to Heal.");
                textBoxDialogMonster.Text = "INVALID ; +200 EXCEEDS MAX HP";
                textBoxDialogMonster.Text = "INVALID ; +200 EXCEEDS MAX HP";
            }
            else if (HealChance <= 75) // If the player's health is less than or equal to 75, the player is healed. 
            {
                HealthPotion(); // Healing potion animation plays.
                playerHealth += 200; // Player's health increases by 200 points.
                if (playerHealth > PlayerHealthOg) // If the player's health is greater than the original health number, the original health number is now set to the player health number.
                {
                    playerHealth = PlayerHealthOg; 
                }
                textBoxDialog.Text = "Healed"; 
                playerhealthbar.Value += (200);
            }
            else if (HealChance > 75) // If healing chance exceeds 75, then healing fails.
            {
                textBoxDialog.Text = "HEALING FAILED!";
                textBoxDialogMonster.Text = "HEALING FAILED!";
            }
            MonsterAccuracyCheck(); // Function for the Overlord's accuracy check plays here.
            await AiAttackAsync();// Awaits AI attack function.
            await Task.Delay(1100); // Task is delayed by 1.1 seconds.
            DeathCheck();//Death Check funcion plays here.
            textBoxTurn.Text = "Turn " + (Turn.ToString());//New turn number set.
            Turn++;//Turn number goes up by 1.
            btnFight.Visible = true; // Fight button is now visible.
            Num1 += 1;// Variable for light attack and heavy attack visibility is increased by one.
            btnStun.Visible = true;// Stun button is now visible.
            btnHeal.Visible = true;// Heal button is now visible.
            btnProtect.Visible = true;// Protect button is now visible.

        }


        //Stun
        private async void btnStun_ClickAsync(object sender, EventArgs e) // Function for the stun button upon click.
        {
            btnFight.Visible = false;// Fight button is now invisible.
            btnHeavyAttack.Visible = false;// Heavy attack button is now invisible.
            btnLightAttack.Visible = false;// Light attack button is now invisible.
            btnStun.Visible = false;// Stun button is now invisible.
            btnHeal.Visible = false;// Heal button is now invisible.
            btnProtect.Visible = false;// Protect button is now invisible.

            await Task.Delay(500); // Task is delayed by 0.5 seconds.
            textBoxDialog.Text = ""; // Text box is now set to empty.
            Random StunRamNumChance = new Random(Guid.NewGuid().GetHashCode()); // Generates a random. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
            int StunChance = StunRamNumChance.Next(0, 101); // Stun chance number is generated.
            TurnCopy = Turn; // Turn copy variable now equals turn.
            if (StunChance >= 25) // If the stun chance exceeds the number of 25.
            {
                if (NewMonsterAccuracy > 0.5) // If the Overlord's accuracy is greater than 50%, this if statement plays.
                {
                    MessageBox.Show("Overlord Accuracy Reduced Overall!");
                    BossHit();
                    NewMonsterAccuracy -= 0.10;//used to set the amount of turns that the accuracy is lowerd for in conjugtion with MonsterAccuracyCheck()
                    textBoxDialog.Text = "Stunned";
                }
                else if (NewMonsterAccuracy <= 0.5)// If the Overlord's accuracy is lesser than or equal to 50%, this if statement plays.
                {
                    MessageBox.Show("You've reached the stun cap! The Overlord's accuracy is reduced by 50%.");
                }
            }
            else if (StunChance < 25) // If stun chance is less than 25.
            {
                textBoxDialog.Text = "You Missed";// miss results in dmg to self
                playerHealth = playerHealth - 100;
            }
            MonsterAccuracyCheck();
            await Task.Delay(1100);
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }
        //Protect
        private async void btnProtect_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);

            textBoxDialog.Text = "";
            Random BlockRamNumChance = new Random(Guid.NewGuid().GetHashCode()); // Generates a random. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
            int BlockChance = BlockRamNumChance.Next(0, 101);

            if (BlockChance >= 75)
            {
                if (BlockDmg < 0.5)
                {
                    MessageBox.Show("10% Less Damage Taken Overall!");
                    BossHit();
                    BlockDmg += 0.1;//10% less dmg taken
                    textBoxDialog.Text = "Protected";
                }
                else if (BlockDmg >= 0.5)
                {
                    MessageBox.Show("You're already at the max damage resistance! (50%)");
                }

            }
            else
            {
                textBoxDialog.Text = "You Missed";
                textBoxDialogMonster.Text = "You Missed";
            }


            MonsterAccuracyCheck();
            await Task.Delay(1100);
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 2;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }

        private void btnItemMenuHandle_Click_1(object sender, EventArgs e)
        {
            Num3 = Num3 % 2;//even numbers have no decimals fight starts at 2 so the buttons start of not visible but when clicked it increases fight by 1
            if (Num3 > 0)
            {
                ItemPanel.Visible = false;
            }
            else
            {
                itemsclick++; // Makes sure the if statement and for-loop below only occur once, so that the items are only randomly generated one time.
                ItemPanel.Visible = true;
            }
            Num3 += 1;

            if (itemsclick == 1) // If our previous boolean variable is true, the following code will play out.
            {
                Button[] CurrentSackofItems = { btnItem1, btnItem2, btnItem3, btnItem4, btnItem5, btnItem6, btnItem7, btnItem8, btnItem9, btnItem10 }; // We make a new array for the item buttons in order to not interfere with the default array.
                string[] PossibleItems = { "Stronger Axe Blade", "Odd Poison", "Potion of Extra Moves", "Potion of Extra Damage", "Throwable Poison", "Overlord Statue", "Old bauble", "Gold coins", "Can of Bone Meal" };
                string[] Information = { "The 'Stronger Axe Blade' allows you to deal '50' more damage points for all continuing turns (Not Stackable ; No effect on Critical Hit ; only effective on Heavy Attack).", "The 'Odd Poison' in your sack of items looks like it's been tampered with.. (Stackable)", "The 'Potion of Extra Moves' allows you to pray to a deity for another chance to attack. (Not Stackable)", "The Potion of 'Extra Damage' allows you to deal twice as much damage on a Critical Hit. (Not Stackable ; Only Effective on Critical Hit & Light Attack & Heavy Attack)", "The 'Throwable Poison' allows you to throw a lethal poison at your enemy, and deal '150' damage points for one turn (Stackable).", "You examine the 'Overlord Statue' trinket in your sack. Weirdly, it looks just like the Overlord.", "You examine the 'Old Bauble' trinket in your sack. It's very dusty, but not very useful.", "You examine the 'Gold Coins' in your sack very closely. It smells like paint and copper.", "You examine the 'Can of Bone Meal' in your sack very closely. The label reads 'Healthy for skeletons, Fatal for humans'. As you continue to examine the can, you realize that consuming the product allows you to instantly regenerate '200' health points for a turn. (Stackable ; Player's Health must be below or equal to 800 points for this to take effect)" };
                for (int i = 0; i < CurrentSackofItems.Length; i++)
                {
                    //Each item in displayed sack will be randomized
                    Random ItemCreator = new Random(Guid.NewGuid().GetHashCode()); // Generates a random number. Cite : stackoverflow.com/questions/1785744/how-do-i-seed-a-random-class-to-avoid-getting-duplicate-random-values
                    Itemchoice = ItemCreator.Next(PossibleItems.Length); // A random number is generated from 0 to the length of the array.

                    Damage[i] = PossibleItems[Itemchoice];
                    CurrentSackofItems[i].Text = PossibleItems[Itemchoice]; // The index of the Possible items to be displayed in the button is selected by the random number, and displayed in the current item's text.
                    CurrentSackofItems[i].Visible = true; // Allows the button to be visible.
                    line[i] = Information[Itemchoice];
                }
                itemsclick = 100; // Makes sure that the randomly generated buttons only are generated once.
            }
        }

        private TaskCompletionSource<bool> WaitForButtonClick; // CITATION : https://stackoverflow.com/questions/35158546/taskcompletionsource-in-async-function, We figured out how to use it to get it to make a button invisible after clicking 'Use'. Basically once you click use, it sets the bool to true, and the button that was clicked prior to use reads that the taskcompletedsource is true. Then afterwards once it reads that, in the next line we made the buttons go invisible, and then set the taskcompletionsource to false so that it wouldn't break the other buttons.

        private async void btnItem1_ClickAsync(object sender, EventArgs e)
        {// make a function, upload functon
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 1;
            buttonchecker = Damage[0];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem1.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem2_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 2;
            buttonchecker = Damage[1];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem2.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem3_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 3;
            buttonchecker = Damage[2];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem3.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem4_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 4;
            buttonchecker = Damage[3];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem4.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem5_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 5;
            buttonchecker = Damage[4];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem5.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem6_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 6;
            buttonchecker = Damage[5];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem6.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem7_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 7;
            buttonchecker = Damage[6];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem7.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem8_ClickAsync(object sender, EventArgs e)
        {

            WaitForButtonClick = new TaskCompletionSource<bool>();

            ButtonSelect = 8;
            buttonchecker = Damage[7];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem8.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem9_ClickAsync(object sender, EventArgs e)
        {

            WaitForButtonClick = new TaskCompletionSource<bool>();

            ButtonSelect = 9;
            buttonchecker = Damage[8];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem9.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem10_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>(); 


            ButtonSelect = 10;
            buttonchecker = Damage[9];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem10.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }
        

        private async void btnUse_ClickAsync(object sender, EventArgs e)
        {
            
            if (Selectedbutton == true)
            {
                WaitForButtonClick.TrySetResult(true);
                if (buttonchecker.Contains("Can of Bone Meal"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    if (playerHealth == 1000)
                    {
                        MessageBox.Show("Eating Bone Meal had no effect. (Stackable ; The Player's Health must be below or equal to 800 points in order for this item to take effect) ");
                        textBoxDialog.Text = "INVALID ; MAX HP";
                        textBoxDialogMonster.Text = "INVALID ; MAX HP";
                    }
                    else if ((playerHealth + 200) > 1000)
                    {
                        MessageBox.Show("Eating Bone Meal had no effect. (Stackable ;The Player's Health must be below or equal to 800 points in order for this item to take effect) ");
                        textBoxDialogMonster.Text = "INVALID ; +200 EXCEEDS MAX HP";
                        textBoxDialogMonster.Text = "INVALID ; +200 EXCEEDS MAX HP";
                    }
                    else if ((playerHealth + 200) <= 1000)
                    {
                        MessageBox.Show("Eating Bone Meal made your bones get stronger. (Stackable ; The Player's Health has been restored 200 points)");
                        playerhealthbar.Value += 200;
                        playerHealth += 200;
                        textBoxPlayerHealth.Text = +playerHealth + "/" + PlayerHealthOg;//health
                        HealthPotion();
                    }   

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;

                }

                if (buttonchecker.Contains("Stronger Axe Blade"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("The Player applies a Stronger Axe Blade. (The Player's Regular Heavy Attack damage is now increased by 50 points per turn [Not Stackable ; Applying more Blades will not increase damage]");
                    StrongerAxeHilt = true;

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Odd Poison"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("You accidentaly spill the poison right onto your body as you tried to throw it! You lost 200 health points due to the lethal poison effects. (Stackable ; The Player Loses 200 Health Points)");
                    playerHealth -= 200;
                    playerhealthbar.Value -= 200;
                    textBoxPlayerHealth.Text = +playerHealth + "/" + PlayerHealthOg;//health

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Throwable Poison"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("The throwable poison smashes against the Overlord's bones and starts to melt them. (Stackable ; The Overlord Loses 150 Health Points)");
                    monsterHealth -= 150;
                    Bosshealth.Value -= 150;
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Potion of Extra Damage"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("You drink the Potion and feel your bones getting stronger. (Not Stackable ; The Player's Critical Hit Multiplier is now 2x instead of 1.25x for both Heavy & Light Attack)");
                    PotionofExtraDamage = true;

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Potion of Extra Moves"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);


                    MessageBox.Show("As you beg and plead for another chance to act against the Overlord, a white light shines above you. 'Please give me more time!' you shout. \n Out of the white light drops an Extension Cord, and you decide to throw it in the Castle fireplace. (Wasted Turn)");

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Overlord Statue"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("You try to consume the statue whole. The Overlord isn't impressed. (Wasted Turn)");

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Old Bauble"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);
                    MessageBox.Show("You try to consume the 'Old Bauble' trinket in your sack. What's wrong with you? (Wasted Turn)");
                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Gold coins"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);
                    MessageBox.Show("You try to consume the 'Gold Coins' in your sack. What's wrong with you? (Wasted Turn)");
                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
            }
            else if (Selectedbutton == false)
            {
                MessageBox.Show("Please select an item before clicking 'Use'");
            }
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {

            if (ButtonSelect == 1)
            {
                MessageBox.Show(line[0]);
            }
            if (ButtonSelect == 2)
            {
                MessageBox.Show(line[1]);
            }
            if (ButtonSelect == 3)
            {
                MessageBox.Show(line[2]);
            }
            if (ButtonSelect == 4)
            {
                MessageBox.Show(line[3]);
            }
            if (ButtonSelect == 5)
            {
                MessageBox.Show(line[4]);
            }
            if (ButtonSelect == 6)
            {
                MessageBox.Show(line[5]);
            }
            if (ButtonSelect == 7)
            {
                MessageBox.Show(line[6]);
            }
            if (ButtonSelect == 8)
            {
                MessageBox.Show(line[7]);
            }
            if (ButtonSelect == 9)
            {
                MessageBox.Show(line[8]);
            }
            if (ButtonSelect == 10)
            {
                MessageBox.Show(line[9]);
            }
            else if (ButtonSelect > 10 || ButtonSelect <= 0)
            {
                MessageBox.Show("Please click on an item in your sack and press info to display any information about the item.");
            }
        }

        private void btnDrop_Click(object sender, EventArgs e)
        {
            if (Selectedbutton == true)
            {
                WaitForButtonClick.TrySetResult(true);
                if (buttonchecker.Contains("Can of Bone Meal")) // CITATION : https://stackoverflow.com/questions/20087352/c-sharp-if-contains we find out how to use .Contains here.
                {

                }

                if (buttonchecker.Contains("Stronger Axe Blade"))
                {

                }
                if (buttonchecker.Contains("Odd Poison"))
                {

                }
                if (buttonchecker.Contains("Throwable Poison"))
                {

                }
                if (buttonchecker.Contains("Potion of Extra Damage"))
                {

                }
                if (buttonchecker.Contains("Potion of Extra Moves"))
                {

                }
                if (buttonchecker.Contains("Gold coins"))
                {

                }
                if (buttonchecker.Contains("Old Bauble"))
                {

                }
                if (buttonchecker.Contains("Overlord Statue"))
                {

                }
            }
            else if (Selectedbutton == false)
            {
                MessageBox.Show("Please select an item before clicking 'Drop'");
            }
        }
    }
}
