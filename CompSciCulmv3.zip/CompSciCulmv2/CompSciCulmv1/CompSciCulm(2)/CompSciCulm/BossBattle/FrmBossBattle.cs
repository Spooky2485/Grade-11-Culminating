﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;


namespace BossBattle
{
    public partial class FrmBossBattle : Form
    {

        //SoundPlayer BossMusic = new SoundPlayer("BossBattleMusic.wav");
        double monsterHealth = 1000;
        double monsterHealthOg = 1000;
        double playerHealth = 1000;
        double PlayerHealthOg = 1000;
        int Turn = 1;
        int Num1 = 2;
        int MonsterAcuracy = 55;
        int TurnCopy;
        double BlockDmg = 1;
        double FireBall;
        /* private void FrmBossBattle_Load(object sender, EventArgs e)
         {
             BossMusic.Play();
         }
         */
        //set up components
        public FrmBossBattle()
        {   
            
            InitializeComponent();
            btnLightAttack.Visible = false;//sets light attack to invisible
            btnHeavyAttack.Visible = false;//sets heavy attack to invisible for later use of fight button
            textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
            textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
            


            picBoxBackground.Controls.Add(IdleMove); // IdleMove added to background
            IdleMove.Location = new Point(-50, 105); // Location is validated
            IdleMove.BackColor = Color.Transparent; // Transparency is validated
            IdleMove.Visible = true;

            
            picBoxBackground.Controls.Add(bossidle); // added idle aniation
            bossidle.BackColor = Color.Transparent; // declares transparency/color
            bossidle.Location = new Point(368, 105); // declares location
            bossidle.Visible = true; // declares visibility as true of idle anim
            

            DeathAnim.Visible = false;//sets all animations to invisible so they are used when called upon
            LightAttackAnimation.Visible = false;
            HeavyAttackAnimation.Visible = false;
            Health.Visible = false;
            PlayerHitAnimation.Visible = false;
            bossattack.Visible = false;


        }

        public void MonsterAccuracyCheck()//checks accuracy and sees how long it lasts for lowering the boss' accuracy for 3 turns
        {
            if (Turn < TurnCopy)
            {
                MonsterAcuracy = 30;
            }
            else
            {
                MonsterAcuracy = 55;
            }
        }
        public void MonsterDamageCheck()//checks dmg to see how much you can resist
        {
            if(BlockDmg < 0.5)
            {
                BlockDmg = 0.5;
            }
            FireBall = FireBall * BlockDmg;
        }
        public async void AttackAnimLightAttackAsync()//Light attack animation
        {
            picBoxBackground.Controls.Remove(IdleMove); // removes idle animation
            picBoxBackground.Controls.Add(LightAttackAnimation); // adds light attack animation
            LightAttackAnimation.Location = new Point(-50, 105); // declares location
            LightAttackAnimation.BackColor = Color.Transparent; // declares color/transparency
            LightAttackAnimation.Visible = true; // declares visibility as true of light attack anim
            await Task.Delay(1750); // 1.75 seconds delay to hold attack
            LightAttackAnimation.Visible = false; // declares visibility as false of light attack anim
            picBoxBackground.Controls.Remove(LightAttackAnimation); // removes light attack anim since it has played out
            IdleAnim2(); //jumps back to idle animation function
        }

        public async void IdleAnim2()
        {
            picBoxBackground.Controls.Add(IdleMove); // added idle aniation
            IdleMove.Location = new Point(-50, 105); // declares location
            IdleMove.BackColor = Color.Transparent; // declares transparency/color
            IdleMove.Visible = true; // declares visibility as true of idle anim
        }

        public async void AttackAnimHeavyAttack()//Heavy attack animation
        {
            picBoxBackground.Controls.Remove(IdleMove);
            picBoxBackground.Controls.Add(HeavyAttackAnimation);
            HeavyAttackAnimation.Location = new Point(-50, 105);
            HeavyAttackAnimation.BackColor = Color.Transparent;
            HeavyAttackAnimation.Visible = true;
            await Task.Delay(1750);
            HeavyAttackAnimation.Visible = false;
            picBoxBackground.Controls.Remove(HeavyAttackAnimation);
            IdleAnim2();
        }

        public async void DeathAnimation()//Death animation
        {
            picBoxBackground.Controls.Remove(IdleMove);
            picBoxBackground.Controls.Add(DeathAnim);
            DeathAnim.Location = new Point(-50, 105);
            DeathAnim.BackColor = Color.Transparent;
            DeathAnim.Visible = true;
            await Task.Delay(900);
            IdleMove.Visible = false;
            picBoxBackground.Controls.Remove(DeathAnim);
        }

        public async void HealthPotion()//heal animation
        {
            picBoxBackground.Controls.Add(Health);
            Health.BringToFront();
            Health.Location = new Point(142, 139);
            Health.BackColor = Color.Transparent;
            Health.Visible = true;
            await Task.Delay(900);
            Health.Visible = false;
            picBoxBackground.Controls.Remove(Health);
        }

        public async void PlayerHit()//hit animation
        {
            picBoxBackground.Controls.Remove(IdleMove);
            picBoxBackground.Controls.Add(PlayerHitAnimation);
            PlayerHitAnimation.Location = new Point(-50, 105);
            PlayerHitAnimation.BackColor = Color.Transparent;
            PlayerHitAnimation.Visible = true;
            await Task.Delay(1400);
            PlayerHitAnimation.Visible = false;
            picBoxBackground.Controls.Remove(PlayerHitAnimation);
            IdleAnim2();
        }

        public async void IdleAnim1()
        {
            picBoxBackground.Controls.Add(bossidle); // added idle aniation
            bossidle.Location = new Point(368, 105); // declares location
            bossidle.BackColor = Color.Transparent; // declares transparency/color
            bossidle.Visible = true; // declares visibility as true of idle anim
        }


        public async void BossAttack1()// boss attack animation
        {
            picBoxBackground.Controls.Remove(bossidle);
            picBoxBackground.Controls.Add(bossattack);
            bossattack.Location = new Point(368, 105);
            bossattack.BackColor = Color.Transparent;
            bossattack.Visible = true;
            await Task.Delay(1400);
            bossattack.Visible = false;
            picBoxBackground.Controls.Remove(bossattack);
            IdleAnim1();
        }

        public void AddToPictureBox(PictureBox child_PB, PictureBox parent_PB)
        {
            Point ptChildScreen = child_PB.PointToScreen(new Point(0, 0));
            parent_PB.Controls.Add(child_PB);
            child_PB.Location = parent_PB.PointToClient(ptChildScreen);
            child_PB.BackColor = Color.Transparent;
            child_PB.Visible = true;
        }

        

       

        public void DeathCheck()//death check which checks if user or boss is dead ending the game 
        {
            if (monsterHealth < 0)
            {
                MessageBox.Show("You Win");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();

            }
            if (playerHealth < 0)
            {
                DeathAnimation();
                MessageBox.Show("You Lose");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();
            }
        }
        

        //MonsterAi
        public async Task AiAttackAsync()// aiattack which is the boss' attack
        {
            await Task.Delay(1000);
            
           
                textBoxDialog.Text = "";
                Random FireBallRamNumChance = new Random();
                int FireBallChance = FireBallRamNumChance.Next(0, 101);
                
                if (FireBallChance <= MonsterAcuracy) //if the generated fireballchance is greater than the monster's accuracy, then the attack will follow thrugh.
                {
                    Random FireBallRamNum = new Random();
                    FireBall = FireBallRamNum.Next(70, 111);//chance for dmg
                    if (FireBallChance <= 9)//chance of crit 15%
                    {
                    MonsterDamageCheck();//block dmg chack
                        BossAttack1();//animation
                        PlayerHit();//player hit animation
                        playerHealth = playerHealth - (FireBall * 1.25);//crit multiplier and attack
                    textBoxDialogMonster.Text = "Critical Hit! " + (FireBall * 1.25).ToString(); ;//dialog
                        textBoxPlayerHealth.Text =  playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                    MonsterDamageCheck();//block dmg check
                    BossAttack1();//animation
                        PlayerHit();//player hit animation
                        playerHealth = playerHealth - FireBall; //attack
                    textBoxDialogMonster.Text = FireBall.ToString();
                    textBoxPlayerHealth.Text =  + playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text =   playerHealth + "/" + PlayerHealthOg;//health
                }
            
            
        }

        
        //fight select
        private void btnFight_Click(object sender, EventArgs e)
        {
            AddToPictureBox(IdleMove, picBoxBackground);
            AddToPictureBox(bossidle, picBoxBackground);

            Num1 = Num1 % 2;//even numbers have no decimals fight starts at 2 so the buttons start of not visible but when clicked it increases fight by 1
            if (Num1 > 0)
            {
                btnLightAttack.Visible = false;//makes moves invisible
                btnHeavyAttack.Visible = false;
            }
            else
            {
                btnLightAttack.Visible = true;//makes moves visible
                btnHeavyAttack.Visible = true;
            }
            Num1 += 1;//alternates
            
        }


        //Heavy attack
        private async void btnHeavyAttack_ClickAsync(object sender, EventArgs e)
        {
            //use while loop to make sure the user isnt able to spam
            
            btnFight.Visible = false;//makes all button invisible
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);//delay
            textBoxDialog.Text = "";
            Random HRamNumChance = new Random();
            int HeavyAttackChance = HRamNumChance.Next(0, 101);

            if (HeavyAttackChance <= 60)//chance of attacking
            {
                Random HRamNum = new Random();
                double HeavyAttack = HRamNum.Next(40, 81);//chance for dmg
                if(HeavyAttackChance <= 9)//chance of crit 15%
                {
                    AttackAnimHeavyAttack();
                    monsterHealth = monsterHealth - (HeavyAttack * 1.25);//crit multiplier and attack
                    textBoxDialog.Text = "Critical Hit! " + (HeavyAttack * 1.25).ToString(); ;//dialog
                    textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
                }
                else
                {
                    AttackAnimHeavyAttack();
                    monsterHealth = monsterHealth - HeavyAttack;
                    textBoxDialog.Text = HeavyAttack.ToString();
                    textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
                }
                
            }
            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;


        }

        //Light attack
        private async void btnLightAttack_ClickAsync(object sender, EventArgs e)
        {
             // initiates animation
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            //TimeSpan timeout = new TimeSpan(0, 0, 1);
            textBoxDialog.Text = "";
            Random LRamNumChance = new Random();
            int LightAttackChance = LRamNumChance.Next(0, 101);
            //Thread.Sleep(timeout);

            if (LightAttackChance <= 95)//chance of attacking
            {
                Random LRamNum = new Random();
                double LightAttack = LRamNum.Next(30, 51);//chance for dmg
                if (LightAttackChance <= 14.25)//chance of crit 15%
                {
                    AttackAnimLightAttackAsync();
                    monsterHealth = monsterHealth - (LightAttack * 1.25);//crit multiplier and attack
                    textBoxDialog.Text = "Critical Hit! " + (LightAttack * 1.25).ToString(); ;//dialog
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                }
                else
                {
                    AttackAnimLightAttackAsync();
                    monsterHealth = monsterHealth - LightAttack;//attack
                    textBoxDialog.Text = LightAttack.ToString();
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                }
            }

            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
            }
            MonsterAccuracyCheck();
            
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }
        //Heal
        private async void btnHeal_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HealRamNumChance = new Random();
            int HealChance = HealRamNumChance.Next(0, 101);
            
            if ( HealChance <= 75)
            {
                HealthPotion();
                double heal = PlayerHealthOg * 0.20;
                playerHealth = playerHealth + heal;
                if (playerHealth > PlayerHealthOg)
                {
                    playerHealth = PlayerHealthOg;
                }
                textBoxDialog.Text = "Healed " + heal.ToString();
                
            }
            else
            {
                HealthPotion();
                double bossHeal = monsterHealthOg * 0.05;
                monsterHealth = monsterHealth + bossHeal;
                if (monsterHealth > monsterHealthOg)
                {
                    monsterHealth = monsterHealthOg;
                }
                textBoxDialogMonster.Text = "Healed " + bossHeal.ToString();
                
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }


        //Stun
        private async void btnStun_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random StunRamNumChance = new Random();
            int StunChance = StunRamNumChance.Next(0, 101);
            TurnCopy = Turn;
            if (StunChance >= 75)
            {
                TurnCopy = TurnCopy + 3;//used to set the amount of turns that the accuracy is lowerd for in conjugtion with MonsterAccuracyCheck()
                textBoxDialog.Text = "Stunned";
            }
            else
            {
                textBoxDialog.Text = "You Missed - 100" ;// miss results in dmg to self
                playerHealth = playerHealth - 100;
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }
        //Protect
        private async void btnProtect_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);

            textBoxDialog.Text = "";
            Random BlockRamNumChance = new Random();
            int BlockChance = BlockRamNumChance.Next(0, 101);

            if (BlockChance >= 75)
            {
                BlockDmg = BlockDmg - 0.1;//10% less dmg taken
                textBoxDialog.Text = "Protected 10% less dmg";
            }
            else
            {
                textBoxDialog.Text = "You Missed - 100";//miss results in dmg to self
                playerHealth = playerHealth - 100;
            }


            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 2;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }
        
    }
}
