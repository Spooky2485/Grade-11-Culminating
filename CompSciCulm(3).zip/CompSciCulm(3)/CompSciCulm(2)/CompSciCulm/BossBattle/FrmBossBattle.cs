﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;


namespace BossBattle
{
    public partial class FrmBossBattle : Form
    {
        public void LeaderBoard()
        {
            if(Turn >= 1)
            {

            }
            if (monsterHealth < 0)
            {
                StreamWriter sw = new StreamWriter("LB.txt");
                sw.Write("\n" + " " + textBoxTurn.Text.ToString());
                sw.Close();
            }
        }

        double monsterHealth = 1000;
        double monsterHealthOg = 1000;
        double playerHealth = 1000;
        double PlayerHealthOg = 1000;
        int Turn = 1;
        int Num1 = 2;
        int MonsterAcuracy = 55;
        int TurnCopy = 0;
        double BlockDmg = 1;
        double FireBall;
        //set up components
        public FrmBossBattle()
        {   
            InitializeComponent();
            btnLightAttack.Visible = false;
            btnHeavyAttack.Visible = false;
            textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;
            textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
        }
        public void MonsterAccuracyCheck()
        {
         if (Turn < TurnCopy)
            {
                MonsterAcuracy = 30;
            }
            else
            {
                MonsterAcuracy = 55;
            }
        }
        public void MonsterDamageCheck()
        {
            FireBall = FireBall * BlockDmg;
        }
        public void DeathCheck()
        {
            if (monsterHealth < 0)
            {
                MessageBox.Show("You Win");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();

            }
            if (playerHealth < 0)
            {
                MessageBox.Show("You Lose");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();
            }
        }
       


        //MonsterAi
        public async Task AiAttackAsync()
        {
            await Task.Delay(1000);
            
           
                textBoxDialog.Text = "";
                Random FireBallRamNumChance = new Random();
                int FireBallChance = FireBallRamNumChance.Next(0, 101);
                
                if (FireBallChance <= MonsterAcuracy) //if the generated fireballchance is greater than the monster's accuracy, then the attack will follow thrugh.
                {
                    Random FireBallRamNum = new Random();
                    FireBall = FireBallRamNum.Next(70, 111);//chance for dmg
                    if (FireBallChance <= 9)//chance of crit 15%
                    {
                    MonsterDamageCheck();
                        playerHealth = playerHealth - (FireBall * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text =  playerHealth + "/" + PlayerHealthOg;//health
                    }
                    else
                    {
                        MonsterDamageCheck();
                        playerHealth = playerHealth - FireBall;
                        textBoxPlayerHealth.Text =  + playerHealth + "/" + PlayerHealthOg;//health
                    }

                }
                else
                {
                    textBoxDialogMonster.Text = "Missed";//dialog
                    textBoxPlayerHealth.Text =   playerHealth + "/" + PlayerHealthOg;//health
                }
            
            


        }

        
        //fight select
        private void btnFight_Click(object sender, EventArgs e)
        {
            Num1 = Num1 % 2;//even numbers have no decimals fight starts at 2 so the buttons start of not visible but when clicked it increases fight by 1
            if (Num1 > 0)
            {
                btnLightAttack.Visible = false;
                btnHeavyAttack.Visible = false;
            }
            else
            {
                btnLightAttack.Visible = true;
                btnHeavyAttack.Visible = true;
            }
            Num1 += 1;
            
        }


        //Heavy attack
        private async void btnHeavyAttack_ClickAsync(object sender, EventArgs e)
        {
            //use while loop to make sure the user isnt able to spam
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HRamNumChance = new Random();
            int HeavyAttackChance = HRamNumChance.Next(0, 101);

            if (HeavyAttackChance <= 60)//chance of attacking
            {
                Random HRamNum = new Random();
                double HeavyAttack = HRamNum.Next(40, 81);//chance for dmg
                if(HeavyAttackChance <= 9)//chance of crit 15%
                {
                    monsterHealth = monsterHealth - (HeavyAttack * 1.25);//crit multiplier and attack
                    textBoxDialog.Text = "Critical Hit!";//dialog
                    textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
                }
                else
                {
                    monsterHealth = monsterHealth - HeavyAttack;
                    textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
                }
                
            }
            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text =  monsterHealth + "/" + monsterHealthOg;//health
            }
            MonsterAccuracyCheck(); //accuracy check
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            

            btnFight.Visible = true;
            Num1 += 1;

            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }

        //Light attack
        private async void btnLightAttack_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            //TimeSpan timeout = new TimeSpan(0, 0, 1);
            textBoxDialog.Text = "";
            Random LRamNumChance = new Random();
            int LightAttackChance = LRamNumChance.Next(0, 101);
            //Thread.Sleep(timeout);

            if (LightAttackChance <= 95)//chance of attacking
            {
                Random LRamNum = new Random();
                double LightAttack = LRamNum.Next(30, 51);//chance for dmg
                if (LightAttackChance <= 14.25)//chance of crit 15%
                {
                    monsterHealth = monsterHealth - (LightAttack * 1.25);//crit multiplier and attack
                    textBoxDialog.Text = "Critical Hit!";//dialog
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                }
                else
                {
                    monsterHealth = monsterHealth - LightAttack;//attack
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                }
            }

            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
            }
            textBoxMonsterAccuracy.Text = (MonsterAcuracy.ToString());
            MonsterAccuracyCheck(); //accuracy check
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
        }
        //Heal
        private async void btnHeal_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HealRamNumChance = new Random();
            int HealChance = HealRamNumChance.Next(0, 101);
            
            if ( HealChance <= 75)
            {
                playerHealth = playerHealth + 300;
                if (playerHealth > PlayerHealthOg)
                {
                    playerHealth = PlayerHealthOg;
                }
                textBoxDialog.Text = "Healed";
                
            }
            else
            {
                monsterHealth = monsterHealth * 1.05;
                if (monsterHealth > monsterHealthOg)
                {
                    monsterHealth = monsterHealthOg;
                }
                textBoxDialogMonster.Text = "Healed";
                
            }
            MonsterAccuracyCheck(); //accuracy check
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
        }


        //Stun
        private async void btnStun_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random StunRamNumChance = new Random();
            int StunChance = StunRamNumChance.Next(0, 101);
            TurnCopy = Turn;
            if (StunChance >= 75)
            {
                TurnCopy = TurnCopy + 3;//used to set the amount of turns that the accuracy is lowerd for in conjugtion with MonsterAccuracyCheck()
                textBoxDialog.Text = "Stunned";
            }
            else
            {
                textBoxDialog.Text = "You Missed";// miss results in dmg to self
                 playerHealth = playerHealth - 100;
            }
            MonsterAccuracyCheck(); //accuracy check
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
        }
        //Protect
        private async void btnProtect_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);

            // code here


            textBoxDialog.Text = "";
            Random BlockRamNumChance = new Random();
            int BlockChance = BlockRamNumChance.Next(0, 101);
            
            if (BlockChance >= 75)
            {
                BlockDmg = BlockDmg - 0.1;//10% less dmg taken
                textBoxDialog.Text = "Protected";
            }
            else
            {
                textBoxDialog.Text = "You Missed";//miss results in dmg to self
                playerHealth = playerHealth - 100;
            }



            MonsterAccuracyCheck(); //accuracy check
            await AiAttackAsync();//attack function
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 2;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }
        

    }
}
