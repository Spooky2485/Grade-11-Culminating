﻿namespace BossBattle
{
    partial class FrmBossBattle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBossBattle));
            this.btnLightAttack = new System.Windows.Forms.Button();
            this.btnHeavyAttack = new System.Windows.Forms.Button();
            this.textBoxMonsterHealth = new System.Windows.Forms.TextBox();
            this.btnFight = new System.Windows.Forms.Button();
            this.btnHeal = new System.Windows.Forms.Button();
            this.btnStun = new System.Windows.Forms.Button();
            this.btnProtect = new System.Windows.Forms.Button();
            this.textBoxDialog = new System.Windows.Forms.TextBox();
            this.textBoxPlayerHealth = new System.Windows.Forms.TextBox();
            this.textBoxDialogMonster = new System.Windows.Forms.TextBox();
            this.textBoxTurn = new System.Windows.Forms.TextBox();
            this.picBoxBackground = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBackground)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLightAttack
            // 
            this.btnLightAttack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLightAttack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLightAttack.Location = new System.Drawing.Point(29, 343);
            this.btnLightAttack.Name = "btnLightAttack";
            this.btnLightAttack.Size = new System.Drawing.Size(100, 40);
            this.btnLightAttack.TabIndex = 0;
            this.btnLightAttack.Text = "Light Attack\r\n dmg 30-50\r\n";
            this.btnLightAttack.UseVisualStyleBackColor = true;
            this.btnLightAttack.Click += new System.EventHandler(this.btnLightAttack_ClickAsync);
            // 
            // btnHeavyAttack
            // 
            this.btnHeavyAttack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHeavyAttack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHeavyAttack.Location = new System.Drawing.Point(135, 344);
            this.btnHeavyAttack.Name = "btnHeavyAttack";
            this.btnHeavyAttack.Size = new System.Drawing.Size(100, 40);
            this.btnHeavyAttack.TabIndex = 1;
            this.btnHeavyAttack.Text = "Heavy Attack\r\n dmg 50 - 80\r\n     ";
            this.btnHeavyAttack.UseVisualStyleBackColor = true;
            this.btnHeavyAttack.Click += new System.EventHandler(this.btnHeavyAttack_ClickAsync);
            // 
            // textBoxMonsterHealth
            // 
            this.textBoxMonsterHealth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxMonsterHealth.Enabled = false;
            this.textBoxMonsterHealth.Location = new System.Drawing.Point(198, 12);
            this.textBoxMonsterHealth.Name = "textBoxMonsterHealth";
            this.textBoxMonsterHealth.Size = new System.Drawing.Size(418, 13);
            this.textBoxMonsterHealth.TabIndex = 4;
            this.textBoxMonsterHealth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnFight
            // 
            this.btnFight.BackColor = System.Drawing.Color.Transparent;
            this.btnFight.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFight.BackgroundImage")));
            this.btnFight.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFight.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFight.Location = new System.Drawing.Point(64, 390);
            this.btnFight.Name = "btnFight";
            this.btnFight.Size = new System.Drawing.Size(100, 40);
            this.btnFight.TabIndex = 8;
            this.btnFight.UseVisualStyleBackColor = false;
            this.btnFight.Click += new System.EventHandler(this.btnFight_Click);
            // 
            // btnHeal
            // 
            this.btnHeal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHeal.BackgroundImage")));
            this.btnHeal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHeal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHeal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHeal.Location = new System.Drawing.Point(241, 390);
            this.btnHeal.Name = "btnHeal";
            this.btnHeal.Size = new System.Drawing.Size(100, 40);
            this.btnHeal.TabIndex = 9;
            this.btnHeal.Text = "Heal";
            this.btnHeal.UseVisualStyleBackColor = true;
            this.btnHeal.Click += new System.EventHandler(this.btnHeal_ClickAsync);
            // 
            // btnStun
            // 
            this.btnStun.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStun.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStun.Location = new System.Drawing.Point(409, 390);
            this.btnStun.Name = "btnStun";
            this.btnStun.Size = new System.Drawing.Size(100, 40);
            this.btnStun.TabIndex = 10;
            this.btnStun.Text = "Stun";
            this.btnStun.UseVisualStyleBackColor = true;
            this.btnStun.Click += new System.EventHandler(this.btnStun_ClickAsync);
            // 
            // btnProtect
            // 
            this.btnProtect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProtect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProtect.Location = new System.Drawing.Point(569, 390);
            this.btnProtect.Name = "btnProtect";
            this.btnProtect.Size = new System.Drawing.Size(100, 40);
            this.btnProtect.TabIndex = 11;
            this.btnProtect.Text = "Block";
            this.btnProtect.UseVisualStyleBackColor = true;
            this.btnProtect.Click += new System.EventHandler(this.btnProtect_ClickAsync);
            // 
            // textBoxDialog
            // 
            this.textBoxDialog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxDialog.Enabled = false;
            this.textBoxDialog.Location = new System.Drawing.Point(198, 38);
            this.textBoxDialog.Name = "textBoxDialog";
            this.textBoxDialog.Size = new System.Drawing.Size(100, 13);
            this.textBoxDialog.TabIndex = 12;
            this.textBoxDialog.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPlayerHealth
            // 
            this.textBoxPlayerHealth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxPlayerHealth.Enabled = false;
            this.textBoxPlayerHealth.Location = new System.Drawing.Point(516, 343);
            this.textBoxPlayerHealth.Name = "textBoxPlayerHealth";
            this.textBoxPlayerHealth.Size = new System.Drawing.Size(174, 13);
            this.textBoxPlayerHealth.TabIndex = 14;
            this.textBoxPlayerHealth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxDialogMonster
            // 
            this.textBoxDialogMonster.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxDialogMonster.Enabled = false;
            this.textBoxDialogMonster.Location = new System.Drawing.Point(516, 324);
            this.textBoxDialogMonster.Name = "textBoxDialogMonster";
            this.textBoxDialogMonster.Size = new System.Drawing.Size(100, 13);
            this.textBoxDialogMonster.TabIndex = 15;
            this.textBoxDialogMonster.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTurn
            // 
            this.textBoxTurn.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTurn.Enabled = false;
            this.textBoxTurn.Location = new System.Drawing.Point(12, 12);
            this.textBoxTurn.Name = "textBoxTurn";
            this.textBoxTurn.Size = new System.Drawing.Size(100, 13);
            this.textBoxTurn.TabIndex = 16;
            this.textBoxTurn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // picBoxBackground
            // 
            this.picBoxBackground.BackColor = System.Drawing.SystemColors.Control;
            this.picBoxBackground.Image = ((System.Drawing.Image)(resources.GetObject("picBoxBackground.Image")));
            this.picBoxBackground.Location = new System.Drawing.Point(-6, -7);
            this.picBoxBackground.Name = "picBoxBackground";
            this.picBoxBackground.Size = new System.Drawing.Size(808, 460);
            this.picBoxBackground.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxBackground.TabIndex = 13;
            this.picBoxBackground.TabStop = false;
            // 
            // FrmBossBattle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBoxTurn);
            this.Controls.Add(this.textBoxDialogMonster);
            this.Controls.Add(this.textBoxPlayerHealth);
            this.Controls.Add(this.textBoxDialog);
            this.Controls.Add(this.btnProtect);
            this.Controls.Add(this.btnStun);
            this.Controls.Add(this.btnHeal);
            this.Controls.Add(this.btnFight);
            this.Controls.Add(this.textBoxMonsterHealth);
            this.Controls.Add(this.btnHeavyAttack);
            this.Controls.Add(this.btnLightAttack);
            this.Controls.Add(this.picBoxBackground);
            this.Name = "FrmBossBattle";
            this.Text = "Fight!";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxBackground)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLightAttack;
        private System.Windows.Forms.Button btnHeavyAttack;
        private System.Windows.Forms.TextBox textBoxMonsterHealth;
        private System.Windows.Forms.Button btnFight;
        private System.Windows.Forms.Button btnHeal;
        private System.Windows.Forms.Button btnStun;
        private System.Windows.Forms.Button btnProtect;
        private System.Windows.Forms.TextBox textBoxDialog;
        private System.Windows.Forms.TextBox textBoxPlayerHealth;
        private System.Windows.Forms.TextBox textBoxDialogMonster;
        private System.Windows.Forms.TextBox textBoxTurn;
        private System.Windows.Forms.PictureBox picBoxBackground;
    }
}

