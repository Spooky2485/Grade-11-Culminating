﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BossBattle
{
    public partial class MainMenu : Form
    {
        int Num1 = 2;
        public MainMenu()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (!File.Exists(@"LB.txt"))
            {
                StreamWriter sw1 = new StreamWriter(@"LB.txt");
                sw1.WriteLine(".Score\tName");
                sw1.Close();
            }
            var FormBossBattle = new FrmBossBattle();
            FormBossBattle.Show();
            this.Hide();
        }

        private void btnInstructions_Click(object sender, EventArgs e)
        {
            Num1 = Num1 % 2;//even numbers have no decimals fight starts at 2 so the buttons start of not visible but when clicked it increases fight by 1
            if (Num1 > 0)
            {
                textBoxInstructions.Visible = false;

            }
            else
            {
                textBoxInstructions.Visible = true;

            }
            Num1 += 1;
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            textBoxInstructions.Text = "Objective: Defeat the overlord using tactics, moves and strategies. Block, Stun, Fight, Light Attack, Heavy Attack and Heal are available for your use! \n Block: Allows you take 10% resistence and \n stun: will either cause the overlord to be unable to attack the you for a turn while you get the advantage of attacking both turns, or you will be unable to attack for one turn.\n Heavy attack and light attack: both cause the overlord to be attacked for a large amount of damage if the attack succeeds, or take no damage at all if the attack fails, but  the chance for failure is significantly higher than the light attack feature, but it does more damage compared to light attack.\n Heal: this means a portion of your health will be restored, or a portion of the boss’ health being restored, a simple hit or miss./n/n health through out the game will be displayed in the green bar at the top of the screen.Are your ready to defeat the overlord ?/nGoodluck";
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
