﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;


namespace BossBattle
{
    public partial class FrmBossBattle : Form
    {
        //SoundPlayer BossMusic = new SoundPlayer("BossBattleMusic.wav");
        string[] Damage = { "a", "a", "a", "a,", "a", "a", "a", "a", "a", "a" }; //Sample Array used for later code.
        string buttonchecker; // String variable for a future button checker.
        bool StrongerAxeHilt = false; // Boolean variable.
        bool ThrowablePoison = false; // Boolean variable.
        bool PotionofExtraDamage = false; // Boolean variable.
        bool Selectedbutton = false; // Boolean variable.
        int ButtonSelect; // Integer variable.
        double monsterHealth = 1000; // Monster health is set to 1000, this will be used for subtraction.
        double monsterHealthOg = 1000; // Monster health is set to 1000.
        double playerHealth = 1000; // Player health is set to 1000, this will be used for subtraction.
        double PlayerHealthOg = 1000; // Player health is set to 1000.
        int Turn = 1; // Integer variable to calculate turn number. 
        int Num1 = 2; // Integer variable.
        int Num3 = 2; // Integer variable.
        double MonsterAccuracy = 55; // Double variable for calculating monster accuracy.
        int TurnCopy; // Integer variable for determining turn copy.
        double BlockDmg = 0; // Double variable for calculating the block multiplier.
        double BossSwordAttack; // Double variable for calculating the Overlord's sword attack count.
        int itemsclick = 0; // Integer variable.
        int Itemchoice; // Integer variable.
        string[] line = { "a", "a", "a", "a,", "a", "a", "a", "a", "a", "a" }; // A sample array that the program will overwrite later.
        double NewMonsterAccuracy = 1; // Double variable for calculating accuracy.
        /* private void FrmBossBattle_Load(object sender, EventArgs e)
         {
             BossMusic.Play();
         }
         */
        //set up components
        public FrmBossBattle()
        {

            InitializeComponent(); // Initialies components of the form.
            BlockDmg = 0; // Block damage multiplier is set to 0.
            Button[] sackofItems = { btnItem1, btnItem2, btnItem3, btnItem4, btnItem5, btnItem6, btnItem7, btnItem8, btnItem9, btnItem10 }; // A collection of all the buttons labelled as 'items' in the item panel.
            playerhealthbar.Value = 1000; // The original value of the Player's health bar displayed as a progress bar.
            Bosshealth.Value = 1000; // The original value of the Boss's health bar displayed as a progress bar.
            btnLightAttack.Visible = false; // The Light attack button doesn't appear until the Player clicks 'fight'.
            btnHeavyAttack.Visible = false; // The Heavy attack button doesn't appear until the Player clicks 'fight'.
            textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg; // A display for the player health in text.
            textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg; // A display for the monster health in text.



            picBoxBackground.Controls.Add(IdleMove); // IdleMove added to background
            IdleMove.Location = new Point(-50, 105); // Location is validated
            IdleMove.BackColor = Color.Transparent; // Transparency is validated
            IdleMove.Visible = true; // The image for the idle player is not visible. 


            picBoxBackground.Controls.Add(bossidle); // Added idle animation.
            bossidle.BackColor = Color.Transparent; // Declares transparency/color.
            bossidle.Location = new Point(368, 105); // Declares location.
            bossidle.Visible = true; // Declares visibility as true of idle animation.



            foreach (var item in sackofItems) // This makes it so that the buttons inside our array are temporarily invisible.
            {
                item.Visible = false; // All buttons in the array will be invisible.
            }
            ItemPanel.Visible = false; // The panel for the sack of items is invisible.
            bossDamaged.Visible = false; //The animation for the boss being hit is not visible.
            DeathAnim.Visible = false; // The death animation is not visible.
            LightAttackAnimation.Visible = false; // The attack animation is not visible.
            HeavyAttackAnimation.Visible = false;// The attack animation is not visible.
            Health.Visible = false; // The Health potion animation is not visible.
            PlayerHitAnimation.Visible = false; // The player hit animation is not visible.
            bossattack.Visible = false; // The boss attack animation is not visible.
            bossDeath.Visible = false; // The boss death animation is not visible. 
        }

        public void MonsterAccuracyCheck() // The Overlord's accuracy function is displayed below.
        {
            MonsterAccuracy = 30 * NewMonsterAccuracy; // The Overlord's accuracy is calculated here.
        }
        public void MonsterDamageCheck() // The Overlord's damage function is displayed below.
        {
            BossSwordAttack = (BossSwordAttack * 0.5) + (BossSwordAttack * BlockDmg); // The Overlord's damage is calculated here.
        }

        public async void BossHit() // The Overlord animation for being hit is carried below.
        {
            picBoxBackground.Controls.Remove(bossidle); // The picture box control removes the Overlord idle animation as a child.
            picBoxBackground.Controls.Add(bossDamaged); // The picture box control adds the Overlord damage animation as a child.
            bossDamaged.Location = new Point(368, 105); // The location of the damaged boss animation is displayed.
            bossDamaged.BackColor = Color.Transparent; // The transparency of the damaged boss animation is displayed. 
            bossDamaged.Visible = true; // The visibility of the damaged boss animation is true.
            await Task.Delay(1400); // Following code is delayed by 1.4 seconds or 1400 miliseconds.
            bossattack.Visible = false; // The visibility of the damaged boss animation is false. 
            picBoxBackground.Controls.Remove(bossDamaged);
            IdleAnim1();
        }
        public async void AttackAnimLightAttackAsync()
        {
            picBoxBackground.Controls.Remove(IdleMove); // removes idle animation
            picBoxBackground.Controls.Add(LightAttackAnimation); // adds light attack animation
            LightAttackAnimation.Location = new Point(-50, 105); // declares location
            LightAttackAnimation.BackColor = Color.Transparent; // declares color/transparency
            LightAttackAnimation.Visible = true; // declares visibility as true of light attack anim
            await Task.Delay(1750); // 1.75 seconds delay to hold attack
            LightAttackAnimation.Visible = false; // declares visibility as false of light attack anim
            picBoxBackground.Controls.Remove(LightAttackAnimation); // removes light attack anim since it has played out
            IdleAnim2(); //jumps back to idle animation function
        }

        public async void IdleAnim2()
        {
            picBoxBackground.Controls.Add(IdleMove); // added idle aniation
            IdleMove.Location = new Point(-50, 105); // declares location
            IdleMove.BackColor = Color.Transparent; // declares transparency/color
            IdleMove.Visible = true; // declares visibility as true of idle anim
        }

        public async void AttackAnimHeavyAttack()
        {
            picBoxBackground.Controls.Remove(IdleMove);
            picBoxBackground.Controls.Add(HeavyAttackAnimation);
            HeavyAttackAnimation.Location = new Point(-50, 105);
            HeavyAttackAnimation.BackColor = Color.Transparent;
            HeavyAttackAnimation.Visible = true;
            await Task.Delay(1750);
            HeavyAttackAnimation.Visible = false;
            picBoxBackground.Controls.Remove(HeavyAttackAnimation);
            IdleAnim2();
        }

        public async void BossDeathAnimation()
        {
            picBoxBackground.Controls.Remove(bossidle);
            picBoxBackground.Controls.Add(bossDeath);
            bossDeath.Location = new Point(-50, 105);
            bossDeath.BackColor = Color.Transparent;
            bossDeath.Visible = true;
            await Task.Delay(900);
            bossDeath.Visible = false;
            picBoxBackground.Controls.Remove(bossDeath);
        }

        public async void DeathAnimation()
        {
            picBoxBackground.Controls.Remove(IdleMove);
            picBoxBackground.Controls.Add(DeathAnim);
            DeathAnim.Location = new Point(-50, 105);
            DeathAnim.BackColor = Color.Transparent;
            DeathAnim.Visible = true;
            await Task.Delay(900);
            IdleMove.Visible = false;
            picBoxBackground.Controls.Remove(DeathAnim);
        }

        public async void HealthPotion()
        {
            picBoxBackground.Controls.Add(Health);
            Health.BringToFront();
            Health.Location = new Point(110, 139);
            Health.BackColor = Color.Transparent;
            Health.Visible = true;
            await Task.Delay(900);
            Health.Visible = false;
            picBoxBackground.Controls.Remove(Health);
        }

        public async void PlayerHit()
        {
            picBoxBackground.Controls.Remove(IdleMove);
            picBoxBackground.Controls.Add(PlayerHitAnimation);
            PlayerHitAnimation.Location = new Point(-50, 105);
            PlayerHitAnimation.BackColor = Color.Transparent;
            PlayerHitAnimation.Visible = true;
            await Task.Delay(1400);
            PlayerHitAnimation.Visible = false;
            picBoxBackground.Controls.Remove(PlayerHitAnimation);
            IdleAnim2();
        }

        public async void IdleAnim1()
        {
            picBoxBackground.Controls.Add(bossidle); // added idle aniation
            bossidle.Location = new Point(368, 105); // declares location
            bossidle.BackColor = Color.Transparent; // declares transparency/color
            bossidle.Visible = true; // declares visibility as true of idle anim
        }


        public async void BossAttack1()
        {
            picBoxBackground.Controls.Remove(bossidle);
            picBoxBackground.Controls.Add(bossattack);
            bossattack.Location = new Point(368, 105);
            bossattack.BackColor = Color.Transparent;
            bossattack.Visible = true;
            await Task.Delay(1400);
            bossattack.Visible = false;
            picBoxBackground.Controls.Remove(bossattack);
            IdleAnim1();
        }

        public void AddToPictureBox(PictureBox child_PB, PictureBox parent_PB)
        {
            Point ptChildScreen = child_PB.PointToScreen(new Point(0, 0));
            parent_PB.Controls.Add(child_PB);
            child_PB.Location = parent_PB.PointToClient(ptChildScreen);
            child_PB.BackColor = Color.Transparent;
            child_PB.Visible = true;
        }

        public void DeathCheck()
        {
            if (monsterHealth < 0)
            {
                BossDeathAnimation();
                MessageBox.Show("You Win");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();
                StreamWriter sw = new StreamWriter(@"LB.txt",true);
                sw.Write("\n"+textBoxTurn.Text);
                sw.Close();
            }
            if (playerHealth < 0)
            {
                DeathAnimation();
                MessageBox.Show("You Lose");
                var EndScreens = new EndScreen();
                EndScreens.Show();
                this.Hide();
            }
        }

        

        //MonsterAi
        public async Task AiAttackAsync()
        {
            await Task.Delay(1000);


            textBoxDialog.Text = "";
            Random SwordSliceChance = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
            int SwordSliceDMG = SwordSliceChance.Next(0, 101);

            if (SwordSliceDMG <= MonsterAccuracy) //if the generated fireballchance is greater than the monster's accuracy, then the attack will follow thrugh.
            {
                Random SwordNum = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
                BossSwordAttack = SwordNum.Next(70, 111);//chance for dmg

                if (SwordSliceDMG <= 9)//chance of crit 15%
                {
                    await Task.Delay(100);
                    try
                    {
                        MonsterDamageCheck();
                        BossAttack1();
                        playerhealthbar.Value -= (int)(BossSwordAttack * 1.25);
                        PlayerHit();
                        playerHealth -= (BossSwordAttack * 1.25);//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                        
                    }
                    catch
                    {
                        playerhealthbar.Value = 0;
                        MonsterDamageCheck();
                        BossAttack1();
                        PlayerHit();
                        playerHealth = 0;//crit multiplier and attack
                        textBoxDialogMonster.Text = "Critical Hit!";//dialog
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                        
                    }
                    
                }
                else if (SwordSliceDMG > 9)
                {
                    await Task.Delay(100);
                    try
                    {
                       
                        MonsterDamageCheck();
                        playerhealthbar.Value -= (int)(BossSwordAttack);
                        BossAttack1();
                        PlayerHit();
                        playerHealth -= BossSwordAttack;
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                       
                    }
                    catch
                    {
                        playerhealthbar.Value = 0;
                        MonsterDamageCheck();
                        BossAttack1();
                        PlayerHit();
                        playerHealth = 0;
                        textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
                        
                    }
                }
            }

            else if (SwordSliceDMG >= MonsterAccuracy)
            {
                textBoxDialogMonster.Text = "Missed";//dialog
                textBoxPlayerHealth.Text = playerHealth + "/" + PlayerHealthOg;//health
            }
        }

        //fight select
        private void btnFight_Click(object sender, EventArgs e)
        {
            AddToPictureBox(IdleMove, picBoxBackground);
            AddToPictureBox(bossidle, picBoxBackground);

            Num1 = Num1 % 2;//even numbers have no decimals fight starts at 2 so the buttons start of not visible but when clicked it increases fight by 1
            if (Num1 > 0)
            {
                btnLightAttack.Visible = false;
                btnHeavyAttack.Visible = false;
            }
            else
            {
                btnLightAttack.Visible = true;
                btnHeavyAttack.Visible = true;
            }
            Num1 += 1;

        }


        //Heavy attack
        private async void btnHeavyAttack_ClickAsync(object sender, EventArgs e)
        {
            //use while loop to make sure the user isnt able to spam

            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HRamNumChance = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
            int HeavyAttackChance = HRamNumChance.Next(0, 101);

            if (HeavyAttackChance <= 60)//chance of attacking
            {
                Random HRamNum = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
                double HeavyAttack = HRamNum.Next(40, 81);//chance for dmg
                if (HeavyAttackChance <= 9 && PotionofExtraDamage == false)//chance of crit 15%
                {
                    try
                    {
                        Bosshealth.Value -= (int)(HeavyAttack * 1.25);

                        AttackAnimHeavyAttack();
                        BossHit();
                        monsterHealth = monsterHealth - (HeavyAttack * 1.25);//crit multiplier and attack
                        textBoxDialog.Text = "Critical Hit!" + (HeavyAttack * 1.25);//dialog
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                    }
                    catch
                    {
                        Bosshealth.Value = 0;

                        AttackAnimHeavyAttack();
                        BossHit();
                        monsterHealth = 0;//crit multiplier and attack
                        textBoxDialog.Text = "Critical Hit!";
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                    }
                }
                else if (HeavyAttackChance <= 9 && PotionofExtraDamage == true)
                {
                    try
                    {
                        Bosshealth.Value -= (int)(HeavyAttack * 2);

                        AttackAnimHeavyAttack();
                        BossHit();
                        monsterHealth = monsterHealth - (HeavyAttack * 2);//crit multiplier and attack
                        textBoxDialog.Text = "Critical Hit!" + (HeavyAttack * 2);//dialog
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                    }
                    catch
                    {
                        Bosshealth.Value = 0;

                        AttackAnimHeavyAttack();
                        BossHit();
                        monsterHealth = 0;//crit multiplier and attack
                        textBoxDialog.Text = "Critical Hit!";//dialog
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;//health
                    }
                }
                else if (HeavyAttackChance > 9 && StrongerAxeHilt == true)
                {
                    try
                    {
                        Bosshealth.Value -= (int)(HeavyAttack + 50);
                        AttackAnimHeavyAttack();
                        BossHit();
                        monsterHealth = monsterHealth - (HeavyAttack + 50);
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health

                    }
                    catch
                    {
                        Bosshealth.Value = 0;
                        AttackAnimHeavyAttack();
                        BossHit();
                        monsterHealth = 0;
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;//health
                    }
                   
                }
                else if (HeavyAttackChance > 9 && HeavyAttackChance <= 60 && StrongerAxeHilt == false)
                {
                    try
                    {
                        Bosshealth.Value -= (int)(HeavyAttack);
                        AttackAnimHeavyAttack();
                        BossHit();
                        monsterHealth = monsterHealth - HeavyAttack;
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                    }
                    catch
                    {
                        Bosshealth.Value = 0;
                        AttackAnimHeavyAttack();
                        BossHit();
                        monsterHealth = 0;
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                    }
                    
                }

            }
            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
            }
            await Task.Delay(1000);
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;
        }

        //Light attack
        private async void btnLightAttack_ClickAsync(object sender, EventArgs e)
        {
            // initiates animation

            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            //TimeSpan timeout = new TimeSpan(0, 0, 1);
            textBoxDialog.Text = "";
            Random LRamNumChance = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
            int LightAttackChance = LRamNumChance.Next(0, 101);
            //Thread.Sleep(timeout);

            if (LightAttackChance <= 95)//chance of attacking
            {
                Random LRamNum = new Random();
                double LightAttack = LRamNum.Next(30, 51);//chance for dmg 
                if (LightAttackChance <= 14.25 && PotionofExtraDamage == false)//chance of crit 15%
                {
                    try
                    {
                        Bosshealth.Value -= (int)(LightAttack * 1.25);
                        AttackAnimLightAttackAsync();
                        BossHit();
                        monsterHealth = monsterHealth - (LightAttack * 1.25);//crit multiplier and attack
                        textBoxDialog.Text = "Critical Hit!";//dialog
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                    }
                    catch
                    {
                        Bosshealth.Value = 0; 
                        AttackAnimLightAttackAsync();
                        BossHit();
                        monsterHealth = monsterHealth - (LightAttack * 1.25);//crit multiplier and attack
                        textBoxDialog.Text = "Critical Hit!";//dialog
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;//health
                    }
                   

                }
                else if (LightAttackChance <= 14.25 && PotionofExtraDamage == true)
                {
                    try
                    {
                        Bosshealth.Value -= (int)(LightAttack * 2);
                        AttackAnimLightAttackAsync();
                        BossHit();
                        monsterHealth = monsterHealth - (LightAttack * 2);//crit multiplier and attack
                        textBoxDialog.Text = "Critical Hit!";//dialog
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                    }
                    catch
                    {
                        Bosshealth.Value = 0;
                        AttackAnimLightAttackAsync();
                        BossHit();
                        monsterHealth = monsterHealth - (LightAttack * 1.25);//crit multiplier and attack
                        textBoxDialog.Text = "Critical Hit!";//dialog
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;//health
                    }
                    
                }

                else if (LightAttackChance > 14.25)
                {
                    try
                    {
                        Bosshealth.Value -= (int)(LightAttack);
                        AttackAnimLightAttackAsync();
                        BossHit();
                        monsterHealth = monsterHealth - LightAttack;//attack
                        textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
                    }
                    catch
                    {
                        Bosshealth.Value = 0;
                        AttackAnimLightAttackAsync();
                        BossHit();
                        monsterHealth = monsterHealth - LightAttack;//attack
                        textBoxMonsterHealth.Text = "0/" + monsterHealthOg;//health
                    }
                   
                }
            }

            else
            {
                textBoxDialog.Text = "You Missed";//dialog
                textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health
            }
            await Task.Delay(1000);
            MonsterAccuracyCheck();

            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }
        //Heal
        private async void btnHeal_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random HealRamNumChance = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
            int HealChance = HealRamNumChance.Next(0, 101);
            if (playerHealth == 1000)
            {
                textBoxDialog.Text = "INVALID ; MAX HP";
                textBoxDialogMonster.Text = "INVALID ;  HP";
            }
            else if ((playerHealth + 200) > 1000)
            {
                textBoxDialogMonster.Text = "INVALID ; +200 EXCEEDS MAX HP";
                textBoxDialogMonster.Text = "INVALID ; +200 EXCEEDS MAX HP";
            }
            else if (HealChance <= 75)
            {
                HealthPotion();
                playerHealth += 200;
                if (playerHealth > PlayerHealthOg)
                {
                    playerHealth = PlayerHealthOg;
                }
                textBoxDialog.Text = "Healed";
                playerhealthbar.Value += (200);
            }
            else
            {
                textBoxDialog.Text = "HEALING FAILED!";
                textBoxDialogMonster.Text = "HEALING FAILED!";
            }
            MonsterAccuracyCheck();
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }


        //Stun
        private async void btnStun_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;

            await Task.Delay(500);
            textBoxDialog.Text = "";
            Random StunRamNumChance = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
            int StunChance = StunRamNumChance.Next(0, 101);
            TurnCopy = Turn;
            if (StunChance >= 25)
            {
                if (NewMonsterAccuracy > 0.5)
                {
                    MessageBox.Show("Overlord Accuracy Reduced Overall!");
                    BossHit();
                    NewMonsterAccuracy -= 0.10;//used to set the amount of turns that the accuracy is lowerd for in conjugtion with MonsterAccuracyCheck()
                    textBoxDialog.Text = "Stunned";
                }
                else if (NewMonsterAccuracy <= 0.5)
                {
                    MessageBox.Show("You've reached the stun cap! The Overlord's accuracy is reduced by 50%.");
                }
            }
            else
            {
                textBoxDialog.Text = "You Missed";// miss results in dmg to self
                playerHealth = playerHealth - 100;
            }
            MonsterAccuracyCheck();
            await Task.Delay(1100);
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 1;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }
        //Protect
        private async void btnProtect_ClickAsync(object sender, EventArgs e)
        {
            btnFight.Visible = false;
            btnHeavyAttack.Visible = false;
            btnLightAttack.Visible = false;
            btnStun.Visible = false;
            btnHeal.Visible = false;
            btnProtect.Visible = false;
            await Task.Delay(500);

            textBoxDialog.Text = "";
            Random BlockRamNumChance = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
            int BlockChance = BlockRamNumChance.Next(0, 101);

            if (BlockChance >= 75)
            {
                if (BlockDmg < 0.5)
                {
                    MessageBox.Show("10% Less Damage Taken Overall!");
                    BossHit();
                    BlockDmg += 0.1;//10% less dmg taken
                    textBoxDialog.Text = "Protected";
                }
                else if (BlockDmg >= 0.5)
                {
                    MessageBox.Show("You're already at the max damage resistance! (50%)");
                }

            }
            else
            {
                textBoxDialog.Text = "You Missed";
                textBoxDialogMonster.Text = "You Missed";
            }


            MonsterAccuracyCheck();
            await Task.Delay(1100);
            await AiAttackAsync();//attack function
            await Task.Delay(1100);
            DeathCheck();//Death Check
            textBoxTurn.Text = "Turn " + (Turn.ToString());
            Turn++;//turn number goes up
            btnFight.Visible = true;
            Num1 += 2;
            btnStun.Visible = true;
            btnHeal.Visible = true;
            btnProtect.Visible = true;

        }

        private void btnItemMenuHandle_Click_1(object sender, EventArgs e)
        {
            Num3 = Num3 % 2;//even numbers have no decimals fight starts at 2 so the buttons start of not visible but when clicked it increases fight by 1
            if (Num3 > 0)
            {
                ItemPanel.Visible = false;
            }
            else
            {
                itemsclick++; // Makes sure the if statement and for-loop below only occur once, so that the items are only randomly generated one time.
                ItemPanel.Visible = true;
            }
            Num3 += 1;

            if (itemsclick == 1) // If our previous boolean variable is true, the following code will play out.
            {
                Button[] CurrentSackofItems = { btnItem1, btnItem2, btnItem3, btnItem4, btnItem5, btnItem6, btnItem7, btnItem8, btnItem9, btnItem10 }; // We make a new array for the item buttons in order to not interfere with the default array.
                string[] PossibleItems = { "Stronger Axe Blade", "Odd Poison", "Potion of Extra Moves", "Potion of Extra Damage", "Throwable Poison", "Overlord Statue", "Old bauble", "Gold coins", "Can of Bone Meal" };
                string[] Information = { "The 'Stronger Axe Blade' allows you to deal '50' more damage points for all continuing turns (Not Stackable ; No effect on Critical Hit ; only effective on Heavy Attack).", "The 'Odd Poison' in your sack of items looks like it's been tampered with.. (Stackable)", "The 'Potion of Extra Moves' allows you to pray to a deity for another chance to attack. (Not Stackable)", "The Potion of 'Extra Damage' allows you to deal twice as much damage on a Critical Hit. (Not Stackable ; Only Effective on Critical Hit & Light Attack & Heavy Attack)", "The 'Throwable Poison' allows you to throw a lethal poison at your enemy, and deal '150' damage points for one turn (Stackable).", "You examine the 'Overlord Statue' trinket in your sack. Weirdly, it looks just like the Overlord.", "You examine the 'Old Bauble' trinket in your sack. It's very dusty, but not very useful.", "You examine the 'Gold Coins' in your sack very closely. It smells like paint and copper.", "You examine the 'Can of Bone Meal' in your sack very closely. The label reads 'Healthy for skeletons, Fatal for humans'. As you continue to examine the can, you realize that consuming the product allows you to instantly regenerate '200' health points for a turn. (Stackable ; Player's Health must be below or equal to 800 points for this to take effect)" };
                for (int i = 0; i < CurrentSackofItems.Length; i++)
                {
                    //Each item in displayed sack will be randomized
                    Random ItemCreator = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
                    Itemchoice = ItemCreator.Next(PossibleItems.Length); // A random number is generated from 0 to the length of the array.

                    Damage[i] = PossibleItems[Itemchoice];
                    CurrentSackofItems[i].Text = PossibleItems[Itemchoice]; // The index of the Possible items to be displayed in the button is selected by the random number, and displayed in the current item's text.
                    CurrentSackofItems[i].Visible = true; // Allows the button to be visible.
                    line[i] = Information[Itemchoice];
                }
                itemsclick = 100; // Makes sure that the randomly generated buttons only are generated once.
            }
        }

        private TaskCompletionSource<bool> WaitForButtonClick;

        private async void btnItem1_ClickAsync(object sender, EventArgs e)
        {// make a function, upload functon
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 1;
            buttonchecker = Damage[0];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem1.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem2_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 2;
            buttonchecker = Damage[1];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem2.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem3_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 3;
            buttonchecker = Damage[2];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem3.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem4_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 4;
            buttonchecker = Damage[3];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem4.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem5_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 5;
            buttonchecker = Damage[4];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem5.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem6_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 6;
            buttonchecker = Damage[5];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem6.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem7_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();
            ButtonSelect = 7;
            buttonchecker = Damage[6];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem7.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem8_ClickAsync(object sender, EventArgs e)
        {

            WaitForButtonClick = new TaskCompletionSource<bool>();

            ButtonSelect = 8;
            buttonchecker = Damage[7];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem8.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem9_ClickAsync(object sender, EventArgs e)
        {

            WaitForButtonClick = new TaskCompletionSource<bool>();

            ButtonSelect = 9;
            buttonchecker = Damage[8];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem9.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }

        private async void btnItem10_ClickAsync(object sender, EventArgs e)
        {
            WaitForButtonClick = new TaskCompletionSource<bool>();


            ButtonSelect = 10;
            buttonchecker = Damage[9];
            Selectedbutton = true;
            await WaitForButtonClick.Task;
            btnItem10.Visible = false;
            WaitForButtonClick.TrySetResult(false);
            Selectedbutton = false;
        }
        

        private async void btnUse_ClickAsync(object sender, EventArgs e)
        {
            
            if (Selectedbutton == true)
            {
                WaitForButtonClick.TrySetResult(true);
                if (buttonchecker.Contains("Can of Bone Meal"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    if (playerHealth == 1000)
                    {
                        MessageBox.Show("Eating Bone Meal had no effect. (Stackable ; The Player's Health must be below or equal to 800 points in order for this item to take effect) ");
                        textBoxDialog.Text = "INVALID ; MAX HP";
                        textBoxDialogMonster.Text = "INVALID ; MAX HP";
                    }
                    else if ((playerHealth + 200) > 1000)
                    {
                        MessageBox.Show("Eating Bone Meal had no effect. (Stackable ;The Player's Health must be below or equal to 800 points in order for this item to take effect) ");
                        textBoxDialogMonster.Text = "INVALID ; +200 EXCEEDS MAX HP";
                        textBoxDialogMonster.Text = "INVALID ; +200 EXCEEDS MAX HP";
                    }
                    else if ((playerHealth + 200) <= 1000)
                    {
                        MessageBox.Show("Eating Bone Meal made your bones get stronger. (Stackable ; The Player's Health has been restored 200 points)");
                        playerhealthbar.Value += 200;
                        playerHealth += 200;
                        textBoxPlayerHealth.Text = +playerHealth + "/" + PlayerHealthOg;//health
                        HealthPotion();
                    }   

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;

                }

                if (buttonchecker.Contains("Stronger Axe Blade"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("The Player applies a Stronger Axe Blade. (The Player's Regular Heavy Attack damage is now increased by 50 points per turn [Not Stackable ; Applying more Blades will not increase damage]");
                    StrongerAxeHilt = true;

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Odd Poison"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("You accidentaly spill the poison right onto your body as you tried to throw it! You lost 200 health points due to the lethal poison effects. (Stackable ; The Player Loses 200 Health Points)");
                    playerHealth -= 200;
                    playerhealthbar.Value -= 200;
                    textBoxPlayerHealth.Text = +playerHealth + "/" + PlayerHealthOg;//health

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Throwable Poison"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("The throwable poison smashes against the Overlord's bones and starts to melt them. (Stackable ; The Overlord Loses 150 Health Points)");
                    monsterHealth -= 150;
                    Bosshealth.Value -= 150;
                    textBoxMonsterHealth.Text = monsterHealth + "/" + monsterHealthOg;//health

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Potion of Extra Damage"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("You drink the Potion and feel your bones getting stronger. (Not Stackable ; The Player's Critical Hit Multiplier is now 2x instead of 1.25x for both Heavy & Light Attack)");
                    PotionofExtraDamage = true;

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Potion of Extra Moves"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);


                    MessageBox.Show("As you beg and plead for another chance to act against the Overlord, a white light shines above you. 'Please give me more time!' you shout. \n Out of the white light drops an Extension Cord, and you decide to throw it in the Castle fireplace. (Wasted Turn)");

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Overlord Statue"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);

                    MessageBox.Show("You try to consume the statue whole. The Overlord isn't impressed. (Wasted Turn)");

                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Old Bauble"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);
                    MessageBox.Show("You try to consume the 'Old Bauble' trinket in your sack. What's wrong with you? (Wasted Turn)");
                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
                if (buttonchecker.Contains("Gold coins"))
                {
                    ItemPanel.Visible = false;
                    btnItemMenuHandle.Visible = false;
                    btnFight.Visible = false;
                    btnHeavyAttack.Visible = false;
                    btnLightAttack.Visible = false;
                    btnStun.Visible = false;
                    btnHeal.Visible = false;
                    btnProtect.Visible = false;
                    await Task.Delay(500);
                    MessageBox.Show("You try to consume the 'Gold Coins' in your sack. What's wrong with you? (Wasted Turn)");
                    MonsterAccuracyCheck();
                    await AiAttackAsync();//attack function
                    await Task.Delay(1100);
                    DeathCheck();//Death Check
                    textBoxTurn.Text = "Turn " + (Turn.ToString());
                    Turn++;//turn number goes up
                    btnFight.Visible = true;
                    btnStun.Visible = true;
                    btnHeal.Visible = true;
                    btnProtect.Visible = true;
                    ItemPanel.Visible = true;
                    btnItemMenuHandle.Visible = true;
                }
            }
            else if (Selectedbutton == false)
            {
                MessageBox.Show("Please select an item before clicking 'Use'");
            }
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {

            if (ButtonSelect == 1)
            {
                MessageBox.Show(line[0]);
            }
            if (ButtonSelect == 2)
            {
                MessageBox.Show(line[1]);
            }
            if (ButtonSelect == 3)
            {
                MessageBox.Show(line[2]);
            }
            if (ButtonSelect == 4)
            {
                MessageBox.Show(line[3]);
            }
            if (ButtonSelect == 5)
            {
                MessageBox.Show(line[4]);
            }
            if (ButtonSelect == 6)
            {
                MessageBox.Show(line[5]);
            }
            if (ButtonSelect == 7)
            {
                MessageBox.Show(line[6]);
            }
            if (ButtonSelect == 8)
            {
                MessageBox.Show(line[7]);
            }
            if (ButtonSelect == 9)
            {
                MessageBox.Show(line[8]);
            }
            if (ButtonSelect == 10)
            {
                MessageBox.Show(line[9]);
            }
            else if (ButtonSelect > 10 || ButtonSelect <= 0)
            {
                MessageBox.Show("Please click on an item in your sack and press info to display any information about the item.");
            }
        }

        private void btnDrop_Click(object sender, EventArgs e)
        {
            if (Selectedbutton == true)
            {
                WaitForButtonClick.TrySetResult(true);
                if (buttonchecker.Contains("Can of Bone Meal"))
                {

                }

                if (buttonchecker.Contains("Stronger Axe Blade"))
                {

                }
                if (buttonchecker.Contains("Odd Poison"))
                {

                }
                if (buttonchecker.Contains("Throwable Poison"))
                {

                }
                if (buttonchecker.Contains("Potion of Extra Damage"))
                {

                }
                if (buttonchecker.Contains("Potion of Extra Moves"))
                {

                }
                if (buttonchecker.Contains("Gold coins"))
                {

                }
                if (buttonchecker.Contains("Old Bauble"))
                {

                }
                if (buttonchecker.Contains("Overlord Statue"))
                {

                }
            }
            else if (Selectedbutton == false)
            {
                MessageBox.Show("Please select an item before clicking 'Drop'");
            }
        }

        
    }
}
